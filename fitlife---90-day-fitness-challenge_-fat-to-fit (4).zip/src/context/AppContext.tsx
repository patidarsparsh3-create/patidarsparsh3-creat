import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Order, Page, Program, UserProfile } from '../types';
import { PROGRAMS } from '../data/programsData';
import {
  saveOrderToSupabase,
  fetchCustomerOrdersFromSupabase,
  testSupabaseConnection,
  SUPABASE_PROJECT_ID
} from '../lib/supabase';
import {
  trackPageView,
  trackAddToCart,
  trackInitiateCheckout,
  trackPurchase
} from '../utils/metaPixel';

interface AppContextType {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  selectedProgramSlug: string | null;
  setSelectedProgramSlug: (slug: string | null) => void;
  cart: CartItem[];
  addToCart: (program: Program) => void;
  removeFromCart: (programId: string) => void;
  clearCart: () => void;
  buyNow: (program: Program) => void;
  cartTotal: number;
  cartCount: number;
  couponCode: string;
  setCouponCode: (code: string) => void;
  discountAmount: number;
  applyCoupon: (code: string) => boolean;
  couponMessage: string | null;
  
  // Protected Downloads & Orders
  purchasedProgramIds: string[];
  isProgramPurchased: (programId: string) => boolean;
  user: UserProfile;
  orders: Order[];
  createOrder: (paymentDetails: { method: string; name: string; email?: string; phone?: string }) => Order;
  currentOrder: Order | null;
  
  // Supabase Integration
  supabaseStatus: { connected: boolean; message: string } | null;
  supabaseProjectId: string;
  syncOrdersWithSupabase: () => Promise<void>;
  
  // Modals & UI helpers
  previewProgram: Program | null;
  setPreviewProgram: (program: Program | null) => void;
  scannerProgram: Program | null;
  setScannerProgram: (program: Program | null) => void;
  thankYouProgram: Program | null;
  setThankYouProgram: (program: Program | null) => void;
  completeScannerPayment: (program: Program, utr?: string) => void;
  isBmiModalOpen: boolean;
  setIsBmiModalOpen: (open: boolean) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  
  // Quick test helper
  unlockAllPlansForDemo: () => void;
  lockAllPlans: () => void;
}

const STORAGE_KEY_PURCHASED = 'fitlife_purchased_plans_v1';
const STORAGE_KEY_ORDERS = 'fitlife_orders_v1';
const STORAGE_KEY_USER = 'fitlife_user_v1';

const defaultUser: UserProfile = {
  id: 'usr_default_01',
  name: 'FitLife Member',
  fitnessGoal: '90-Day Fat to Fit Transformation',
  purchasedProgramIds: [],
  orders: []
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedProgramSlug, setSelectedProgramSlug] = useState<string | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [couponCode, setCouponCode] = useState<string>('');
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [couponMessage, setCouponMessage] = useState<string | null>(null);
  
  const [previewProgram, setPreviewProgram] = useState<Program | null>(null);
  const [scannerProgram, setScannerProgram] = useState<Program | null>(null);
  const [thankYouProgram, setThankYouProgram] = useState<Program | null>(null);
  const [isBmiModalOpen, setIsBmiModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [supabaseStatus, setSupabaseStatus] = useState<{ connected: boolean; message: string } | null>(null);

  // Persistence
  const [purchasedProgramIds, setPurchasedProgramIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_PURCHASED);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_ORDERS);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_USER);
      return stored ? JSON.parse(stored) : defaultUser;
    } catch {
      return defaultUser;
    }
  });

  // Sync with Supabase on mount
  useEffect(() => {
    testSupabaseConnection().then(status => {
      setSupabaseStatus(status);
    });

    fetchCustomerOrdersFromSupabase().then(remoteOrders => {
      if (remoteOrders && remoteOrders.length > 0) {
        setOrders(prev => {
          const existingIds = new Set(prev.map(o => o.orderId));
          const newItems = remoteOrders.filter(o => !existingIds.has(o.orderId));
          return [...prev, ...newItems];
        });

        // Auto unlock downloaded plans from remote database
        const remotePlanIds = remoteOrders.flatMap(o => o.items.map(it => it.programId));
        setPurchasedProgramIds(prev => Array.from(new Set([...prev, ...remotePlanIds])));
      }
    }).catch(err => {
      console.warn('Initial Supabase fetch:', err);
    });
  }, []);

  const syncOrdersWithSupabase = async () => {
    showToast('Syncing orders with Supabase database...');
    const status = await testSupabaseConnection();
    setSupabaseStatus(status);
    
    // Sync any local orders to Supabase
    for (const ord of orders) {
      await saveOrderToSupabase(ord, user.fitnessGoal);
    }

    const remoteOrders = await fetchCustomerOrdersFromSupabase();
    if (remoteOrders && remoteOrders.length > 0) {
      setOrders(prev => {
        const existingIds = new Set(prev.map(o => o.orderId));
        const newItems = remoteOrders.filter(o => !existingIds.has(o.orderId));
        return [...prev, ...newItems];
      });
      const remotePlanIds = remoteOrders.flatMap(o => o.items.map(it => it.programId));
      setPurchasedProgramIds(prev => Array.from(new Set([...prev, ...remotePlanIds])));
    }
    showToast('Supabase database sync complete!');
  };

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PURCHASED, JSON.stringify(purchasedProgramIds));
    } catch (e) {
      console.error(e);
    }
  }, [purchasedProgramIds]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ORDERS, JSON.stringify(orders));
    } catch (e) {
      console.error(e);
    }
  }, [orders]);

  // Track Meta Pixel PageView whenever user navigates pages
  useEffect(() => {
    trackPageView(currentPage);
  }, [currentPage]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3800);
  };

  const isProgramPurchased = (programId: string): boolean => {
    return purchasedProgramIds.includes(programId);
  };

  const addToCart = (program: Program) => {
    setCart((prev) => {
      const exists = prev.find((item) => item.programId === program.id);
      if (exists) {
        showToast(`"${program.title}" is already in your cart`);
        return prev;
      }
      showToast(`Added "${program.title}" to cart (₹${program.price})`);
      
      // Fire Meta Pixel AddToCart event
      trackAddToCart({
        content_name: program.title,
        content_ids: [program.id],
        value: program.price,
        currency: 'INR'
      });

      return [...prev, {
        programId: program.id,
        title: program.title,
        price: program.price,
        quantity: 1,
        slug: program.slug
      }];
    });
  };

  const buyNow = (program: Program) => {
    // If user already owns it, send directly to downloads
    if (isProgramPurchased(program.id)) {
      showToast('You already own this plan! Opening download vault...');
      setCurrentPage('download-plans');
      return;
    }

    // Fire Meta Pixel InitiateCheckout event
    trackInitiateCheckout({
      value: program.price,
      num_items: 1,
      content_ids: [program.id],
      currency: 'INR'
    });

    setCart((prev) => {
      const exists = prev.find((item) => item.programId === program.id);
      if (exists) return prev;
      return [...prev, {
        programId: program.id,
        title: program.title,
        price: program.price,
        quantity: 1,
        slug: program.slug
      }];
    });
    setCurrentPage('checkout');
  };

  const removeFromCart = (programId: string) => {
    setCart((prev) => prev.filter((item) => item.programId !== programId));
    showToast('Plan removed from cart');
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotalBeforeDiscount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartTotal = Math.max(0, cartTotalBeforeDiscount - discountAmount);
  const cartCount = cart.length;

  const applyCoupon = (code: string): boolean => {
    const clean = code.trim().toUpperCase();
    if (clean === 'FITLIFE50' || clean === 'TRANSFORM50') {
      const discount = Math.min(50, cartTotalBeforeDiscount > 0 ? 50 : 0);
      setDiscountAmount(discount);
      setCouponMessage('Coupon applied! ₹50 Instant Discount');
      showToast('Coupon FITLIFE50 applied successfully! ₹50 off');
      return true;
    } else if (clean === 'FREEDEMO') {
      setDiscountAmount(cartTotalBeforeDiscount);
      setCouponMessage('Demo 100% coupon applied!');
      showToast('100% demo voucher applied');
      return true;
    } else {
      setCouponMessage('Invalid coupon code. Try "FITLIFE50"');
      setDiscountAmount(0);
      showToast('Invalid coupon code');
      return false;
    }
  };

  const createOrder = (paymentDetails: { method: string; name: string; email?: string; phone?: string }): Order => {
    const orderId = `FL-${Math.floor(100000 + Math.random() * 900000)}`;
    const txId = `TXN_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    
    const newOrder: Order = {
      orderId,
      date: new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      customerName: paymentDetails.name || user.name,
      customerEmail: paymentDetails.email || user.email,
      customerPhone: paymentDetails.phone || user.phone,
      items: [...cart],
      subtotal: cartTotalBeforeDiscount,
      discount: discountAmount,
      total: cartTotal,
      paymentMethod: paymentDetails.method,
      paymentStatus: 'completed',
      transactionId: txId
    };

    // Unlock purchased plan IDs
    const newPurchased = Array.from(new Set([...purchasedProgramIds, ...cart.map((c) => c.programId)]));
    setPurchasedProgramIds(newPurchased);

    setOrders((prev) => [newOrder, ...prev]);
    setCurrentOrder(newOrder);

    // Update user info
    setUser((prev) => ({
      ...prev,
      name: paymentDetails.name || prev.name,
      email: paymentDetails.email || prev.email,
      phone: paymentDetails.phone || prev.phone,
      purchasedProgramIds: newPurchased,
      orders: [newOrder, ...prev.orders]
    }));

    // Clear cart
    clearCart();
    setDiscountAmount(0);
    setCouponCode('');
    setCouponMessage(null);

    // Persist to Supabase database asynchronously
    saveOrderToSupabase(newOrder, user.fitnessGoal).then(res => {
      if (res.success) {
        console.log('Order successfully recorded in Supabase database:', newOrder.orderId);
      }
    }).catch(err => {
      console.warn('Supabase order record skipped:', err);
    });

    // Fire Meta Pixel Purchase conversion with real customer data
    trackPurchase({
      value: newOrder.total,
      currency: 'INR',
      content_ids: newOrder.items.map((i) => i.programId),
      content_name: newOrder.items.map((i) => i.title).join(', '),
      order_id: newOrder.orderId,
      num_items: newOrder.items.length,
      customer: {
        name: newOrder.customerName,
        email: newOrder.customerEmail,
        phone: newOrder.customerPhone,
        external_id: user.id
      }
    });

    return newOrder;
  };

  const completeScannerPayment = (program: Program, utr?: string) => {
    const orderId = `FL-${Math.floor(100000 + Math.random() * 900000)}`;
    const txId = utr || `UPI_${Date.now()}`;

    const newOrder: Order = {
      orderId,
      date: new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      customerName: user.name,
      items: [{
        programId: program.id,
        title: program.title,
        price: program.price,
        quantity: 1,
        slug: program.slug
      }],
      subtotal: program.price,
      discount: 0,
      total: program.price,
      paymentMethod: 'PHONEPE_UPI_QR',
      paymentStatus: 'completed',
      transactionId: txId
    };

    const newPurchased = Array.from(new Set([...purchasedProgramIds, program.id]));
    setPurchasedProgramIds(newPurchased);
    setOrders((prev) => [newOrder, ...prev]);
    setCurrentOrder(newOrder);

    setUser((prev) => ({
      ...prev,
      purchasedProgramIds: newPurchased,
      orders: [newOrder, ...prev.orders]
    }));

    // Persist to Supabase database asynchronously
    saveOrderToSupabase(newOrder, 'PhonePe UPI QR Purchase').then(res => {
      if (res.success) {
        console.log('UPI QR Order recorded in Supabase database:', newOrder.orderId);
      }
    }).catch(err => {
      console.warn('Supabase UPI QR save error:', err);
    });

    // Fire Meta Pixel Purchase conversion with real customer data
    trackPurchase({
      value: newOrder.total,
      currency: 'INR',
      content_ids: [program.id],
      content_name: program.title,
      order_id: newOrder.orderId,
      num_items: 1,
      customer: {
        name: user.name,
        email: user.email,
        phone: user.phone,
        external_id: user.id
      }
    });

    // Close scanner modal and immediately open Thank You animation modal
    setScannerProgram(null);
    setThankYouProgram(program);
  };

  const unlockAllPlansForDemo = () => {
    const allIds = PROGRAMS.map((p) => p.id);
    setPurchasedProgramIds(allIds);
    showToast('Unlocked all 5 FitLife plans for demonstration!');
  };

  const lockAllPlans = () => {
    setPurchasedProgramIds([]);
    showToast('Reset all downloads to locked status.');
  };

  return (
    <AppContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        selectedProgramSlug,
        setSelectedProgramSlug,
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        buyNow,
        cartTotal,
        cartCount,
        couponCode,
        setCouponCode,
        discountAmount,
        applyCoupon,
        couponMessage,
        purchasedProgramIds,
        isProgramPurchased,
        user,
        orders,
        createOrder,
        currentOrder,
        supabaseStatus,
        supabaseProjectId: SUPABASE_PROJECT_ID,
        syncOrdersWithSupabase,
        previewProgram,
        setPreviewProgram,
        scannerProgram,
        setScannerProgram,
        thankYouProgram,
        setThankYouProgram,
        completeScannerPayment,
        isBmiModalOpen,
        setIsBmiModalOpen,
        isAuthModalOpen,
        setIsAuthModalOpen,
        toastMessage,
        showToast,
        unlockAllPlansForDemo,
        lockAllPlans
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
