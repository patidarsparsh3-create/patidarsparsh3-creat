import { Program } from '../types';

export const PROGRAMS: Program[] = [
  {
    id: 'fl-90-day-challenge',
    slug: '90-day-challenge',
    title: '90-Day Fat to Fit Complete Challenge',
    tagline: '90 Days. One Goal. Fat to Fit.',
    shortDesc: 'The flagship complete transformation system combining metabolic fat loss, lean muscle retention, posture alignment, and a 12-week step-by-step roadmap.',
    duration: '90 Days (12 Weeks)',
    level: 'Beginner to Advanced (Progressive 3-Phase)',
    price: 250,
    originalPrice: 1499,
    category: 'fat-loss',
    badge: 'Most Popular',
    accentColor: 'emerald',
    pdfFileName: 'FitLife_90Day_FatToFit_Complete_Plan.pdf',
    highlights: [
      'Comprehensive 3-Phase Transformation Protocol (Days 1–30, 31–60, 61–90)',
      'Dual-Track Diet Chart: 100% Indian Vegetarian & High-Protein Non-Veg Plans',
      'Daily Calorie Deficit Guide & Macro Calculator (1500–2200 kcal tiers)',
      'Home & Gym Workout Variations (No expensive gear required)',
      'Built-in Posture & Mobility Morning Routines (10 mins/day)',
      'Weekly Habit Trackers & Body Measurement Milestones'
    ],
    benefits: [
      'Lose 6–12 kg of stubborn visceral and subcutaneous fat safely',
      'Build functional lean muscle tone and boost resting metabolic rate',
      'Eliminate desk-slouch and forward head posture',
      'Gain all-day sustained energy without sugar crashes or starvation',
      'Develop unbreakable health routines that stick for life'
    ],
    targetAudience: [
      'Anyone struggling with stubborn belly fat or weight plateaus',
      'Busy working professionals needing structured, realistic 45-minute sessions',
      'Beginners wanting clear, step-by-step guidance without confusing gym jargon',
      'Individuals returning to fitness after a long break'
    ],
    sampleDaysWorkout: [
      {
        dayNumber: 1,
        dayTitle: 'Day 1: Full-Body Metabolic Ignition',
        focus: 'Compound Lower & Upper Activation + Core Stability',
        warmUp: '5 mins: Arm circles, leg swings, cat-cow spine waves, 30 jumping jacks',
        coolDown: '5 mins: Standing quad stretch, child pose, hamstring reach (hold 30s each)',
        cardioStepGoal: '8,000 steps daily baseline',
        exercises: [
          {
            name: 'Bodyweight / Goblet Squats',
            targetMuscle: 'Quadriceps, Glutes, Core',
            sets: '3 sets',
            repsOrTime: '12-15 reps',
            rest: '60 sec',
            formCue: 'Chest up, knees tracking over toes, descend to 90 degrees smoothly.'
          },
          {
            name: 'Incline or Floor Push-Ups',
            targetMuscle: 'Chest, Anterior Deltoids, Triceps',
            sets: '3 sets',
            repsOrTime: '8-12 reps',
            rest: '60 sec',
            formCue: 'Elbows tucked at 45 degrees, maintain a rigid plank from heels to head.'
          },
          {
            name: 'Dumbbell / Backpack Bent-Over Rows',
            targetMuscle: 'Upper Back, Rhomboids, Lats',
            sets: '3 sets',
            repsOrTime: '12 reps',
            rest: '60 sec',
            formCue: 'Hinge at the hips, flat neutral back, pull elbows towards hips.'
          },
          {
            name: 'Forearm Plank with Squeeze',
            targetMuscle: 'Transverse Abdominis & Deep Core',
            sets: '3 sets',
            repsOrTime: '30-45 sec hold',
            rest: '45 sec',
            formCue: 'Engage glutes and pull navel toward spine; breathe calmly.'
          }
        ]
      },
      {
        dayNumber: 2,
        dayTitle: 'Day 2: Low-Impact HIIT & Core Sculpt',
        focus: 'Fat Oxidation & Cardiovascular Endurance',
        warmUp: '5 mins: Light jogging in place, torso twists, hip openers',
        coolDown: '5 mins: Cobra stretch, seated forward fold, deep diaphragm breathing',
        cardioStepGoal: '9,000 steps daily baseline',
        exercises: [
          {
            name: 'Reverse Lunges with Knee Drive',
            targetMuscle: 'Hamstrings, Glutes, Balance',
            sets: '3 sets',
            repsOrTime: '10 reps each leg',
            rest: '45 sec',
            formCue: 'Step back softly, lower back knee an inch above floor, push through front heel.'
          },
          {
            name: 'Pike Shoulder Taps',
            targetMuscle: 'Shoulder Stabilizers, Core',
            sets: '3 sets',
            repsOrTime: '16 taps total',
            rest: '45 sec',
            formCue: 'Keep hips square and minimize rocking side-to-side.'
          },
          {
            name: 'Brisk Mountain Climbers',
            targetMuscle: 'Cardio & Abdominals',
            sets: '3 sets',
            repsOrTime: '35 seconds',
            rest: '45 sec',
            formCue: 'Drive knees toward chest with controlled rhythmic pacing.'
          },
          {
            name: 'Deadbug Core Control',
            targetMuscle: 'Lower Abs & Lumbar Stability',
            sets: '3 sets',
            repsOrTime: '12 reps alternating',
            rest: '45 sec',
            formCue: 'Press lower back flush against the ground at all times.'
          }
        ]
      },
      {
        dayNumber: 3,
        dayTitle: 'Day 3: Active Recovery & Deep Mobility Reset',
        focus: 'Lactic Acid Flush, Postural Restoration & Walking',
        warmUp: '3 mins: Deep diaphragmatic breathing in cross-legged seat',
        coolDown: '5 mins: Reclined spinal twists and mindful body scan',
        cardioStepGoal: '10,000 brisk steps outdoors or on treadmill',
        isRestDay: true,
        exercises: [
          {
            name: 'World’s Greatest Stretch',
            targetMuscle: 'Hips, Thoracic Spine, Hamstrings',
            sets: '2 sets',
            repsOrTime: '5 reps per side',
            rest: '30 sec',
            formCue: 'Lunge forward, drop inside elbow to floor, then rotate arm up toward sky.'
          },
          {
            name: 'Cat-Cow Spinal Waves',
            targetMuscle: 'Full Spine & Pelvis',
            sets: '2 sets',
            repsOrTime: '10 slow cycles',
            rest: '30 sec',
            formCue: 'Sync breath with movement: inhale arch, exhale round spine upward.'
          },
          {
            name: 'Deep Squat Hold (Malasana)',
            targetMuscle: 'Ankle Dorsiflexion, Groin, Hips',
            sets: '2 sets',
            repsOrTime: '45 sec hold',
            rest: '30 sec',
            formCue: 'Use a doorway or wall for balance if heels lift off ground.'
          }
        ]
      }
    ],
    sampleDaysDiet: [
      {
        dayNumber: 1,
        calorieTarget: '1,650 - 1,800 kcal (Fat Loss Deficit)',
        breakfast: {
          veg: 'High-Protein Moong Dal Chilla (2) filled with grated paneer (50g), green mint chutney, and green tea.',
          nonVeg: '3 Whole Eggs Scramble with spinach & tomatoes, 1 slice multigrain toast, and black coffee.',
          calories: '380 kcal | 24g Protein'
        },
        lunch: {
          veg: '1 bowl Brown Rice or 2 Phulkas + 1 cup Yellow Dal Tadka + 1 cup Paneer Bhurji / Soya chunks sabzi + large mixed cucumber-carrot salad.',
          nonVeg: '1 bowl Brown Rice or 2 Phulkas + 150g Grilled Lemon-Herb Chicken Breast + 1 cup cucumber salad + light curd (100g).',
          calories: '520 kcal | 35g Protein'
        },
        snacks: {
          veg: 'Roasted Makhana (Fox nuts) 30g + 1 fistful of roasted chana + green tea / black coffee.',
          nonVeg: 'Boiled Egg Whites (3) with chaat masala or 1 scoop Whey Protein in chilled water with an apple.',
          calories: '180 kcal | 12g Protein'
        },
        dinner: {
          veg: 'Warm Vegetable Stir-Fry with 80g Tofu / Paneer in olive oil + 1 bowl Masoor Dal soup with flaxseeds.',
          nonVeg: '150g Pan-seared Fish or Chicken Tikka with roasted broccoli, bell peppers, and 1 multigrain roti.',
          calories: '450 kcal | 32g Protein'
        },
        hydrationGoal: '3.5 Liters of pure water (start day with 500ml lukewarm lemon-cinnamon water)',
        keyNutritionTip: 'Eat salad 10 minutes prior to lunch and dinner. The soluble fiber stabilizes blood sugar spikes and enhances fullness.'
      },
      {
        dayNumber: 2,
        calorieTarget: '1,650 - 1,800 kcal (Fat Loss Deficit)',
        breakfast: {
          veg: 'Rolled Oats Porridge (45g) cooked in almond milk with 1 scoop plant protein, chia seeds, and half sliced banana.',
          nonVeg: 'Egg White Omelet (4 whites + 1 yolk) loaded with mushrooms & onions + 1 cup unsweetened black coffee.',
          calories: '390 kcal | 26g Protein'
        },
        lunch: {
          veg: 'Quinoa or Millets Khichdi with vegetables + 1 bowl low-fat curd (150g) + raw sprouted mung salad with lime.',
          nonVeg: '2 Phulkas + 150g Chicken Curry cooked in 1 tsp cold-pressed oil + 1 cup mixed vegetable salad + buttermilk.',
          calories: '510 kcal | 36g Protein'
        },
        snacks: {
          veg: 'Sprouted Green Moong Chaat with onions, tomato, lemon and rock salt (1 small bowl).',
          nonVeg: 'Greek Yogurt (100g) with 5 crushed almonds and 1 tsp sunflower seeds.',
          calories: '170 kcal | 14g Protein'
        },
        dinner: {
          veg: 'Grilled Tofu Steak / Paneer Tikka (100g) with steamed beans and clear vegetable soup.',
          nonVeg: 'Egg Curry (2 boiled eggs in light tomato gravy) + 1 small phulka + sauteed zucchini and spinach.',
          calories: '440 kcal | 30g Protein'
        },
        hydrationGoal: '3.5 Liters (carry a 1-liter marked bottle and finish 3 refills before 7 PM)',
        keyNutritionTip: 'Cut off eating at least 2.5 hours before bedtime. This promotes nighttime growth hormone release and digestive rest.'
      },
      {
        dayNumber: 3,
        calorieTarget: '1,700 kcal (Metabolic Maintenance Refresh)',
        breakfast: {
          veg: '2 Multigrain Idlis with high-protein Sambhar (lots of drumsticks & dal) + coconut-mint chutney (1 tsp).',
          nonVeg: '2 Poached Eggs on avocado toast (1 slice whole grain) + cherry tomatoes and black tea.',
          calories: '370 kcal | 20g Protein'
        },
        lunch: {
          veg: '1 cup Cooked Brown Basmati + 1 cup Rajma (Kidney Beans) cooked in ginger-garlic + fresh beetroot salad.',
          nonVeg: 'Grilled Chicken Salad bowl with mixed greens, walnuts, olive oil-lemon dressing, and 1 slice sour dough.',
          calories: '530 kcal | 33g Protein'
        },
        snacks: {
          veg: '1 Medium Apple with 1 tbsp unsweetened peanut butter + herbal chamomile tea.',
          nonVeg: '2 Boiled Eggs with black pepper + handful of roasted almonds (10 pieces).',
          calories: '200 kcal | 11g Protein'
        },
        dinner: {
          veg: 'Paneer Bhurji (100g low-fat paneer) with diced capsicum + 1 multi-millet roti + warm turmeric-cinnamon milk.',
          nonVeg: 'Baked Herb-Crusted Fish Fillet (160g) with steamed asparagus or beans + light vegetable broth.',
          calories: '460 kcal | 34g Protein'
        },
        hydrationGoal: '3.5 Liters + 1 glass of tender coconut water for natural electrolyte balance',
        keyNutritionTip: 'Hydrate between meals rather than gulping large amounts during eating to optimize stomach acid concentration.'
      }
    ]
  },
  {
    id: 'fl-fat-loss',
    slug: 'fat-loss',
    title: 'Fat Loss Accelerator & Calorie Mastery',
    tagline: 'Burn Stubborn Fat While Preserving Lean Muscle',
    shortDesc: 'A laser-focused fat shredding program with scientific calorie-conscious nutrition, HIIT conditioning, and weekly progressive volume.',
    duration: '60 Days (8 Weeks)',
    level: 'All Fitness Levels',
    price: 250,
    originalPrice: 999,
    category: 'fat-loss',
    badge: 'High Conversion',
    accentColor: 'orange',
    pdfFileName: 'FitLife_FatLoss_Accelerator_Plan.pdf',
    highlights: [
      'Personalized Caloric Deficit Calculators for Men & Women',
      'Cardio & Strength Synergistic Workouts for Accelerated Fat Burn',
      'Weekly Progression Ladder to prevent metabolic adaptation',
      'Anti-Craving Snack Directory with healthy low-calorie alternatives',
      'Weekend Social Dining Survival Guide (How to dine out & stay in deficit)'
    ],
    benefits: [
      'Target stubborn fat reserves around waistline and hips',
      'Maintain firm muscle definition while shedding fat',
      'Learn how to track and prep meals in under 20 minutes',
      'Eliminate chronic bloating with clean digestive foods'
    ],
    targetAudience: [
      'Anyone looking to drop body fat percentage rapidly and safely',
      'People who hit an annoying weight loss plateau on typical diets',
      'Individuals wanting easy-to-follow Indian and continental recipes'
    ],
    sampleDaysWorkout: [
      {
        dayNumber: 1,
        dayTitle: 'Lower Body Calorie Torcher',
        focus: 'Glutes, Quads & Metabolic Conditioning',
        warmUp: '5 mins: Leg swings, bodyweight squats, high knees',
        coolDown: '5 mins: Quad and calf static stretches',
        cardioStepGoal: '10,000 steps',
        exercises: [
          {
            name: 'Bulgarian Split Squats',
            targetMuscle: 'Quads & Glute Max',
            sets: '3 sets',
            repsOrTime: '10 reps each leg',
            rest: '60 sec',
            formCue: 'Keep front shin vertical, drive torso slightly forward to load glutes.'
          },
          {
            name: 'Romanian Dumbbell Deadlifts',
            targetMuscle: 'Hamstrings & Posterior Chain',
            sets: '3 sets',
            repsOrTime: '12 reps',
            rest: '60 sec',
            formCue: 'Push hips back until you feel deep hamstring stretch; keep lats tight.'
          },
          {
            name: 'Jump Rope or Ghost Skips',
            targetMuscle: 'Calves & Cardiovascular System',
            sets: '4 rounds',
            repsOrTime: '45 seconds continuous',
            rest: '30 sec',
            formCue: 'Stay on the balls of your feet, small wrist rotations.'
          }
        ]
      },
      {
        dayNumber: 2,
        dayTitle: 'Upper Body Tone & Core',
        focus: 'Back, Shoulders, Chest & Core Tightening',
        warmUp: '5 mins: Arm swings, band pull-aparts, thoracic rotations',
        coolDown: '5 mins: Doorway chest stretch and child pose',
        cardioStepGoal: '9,000 steps',
        exercises: [
          {
            name: 'Dumbbell Overhead Shoulder Press',
            targetMuscle: 'Deltoids & Triceps',
            sets: '3 sets',
            repsOrTime: '10-12 reps',
            rest: '60 sec',
            formCue: 'Press weights overhead without arching the lower back.'
          },
          {
            name: 'Lat Pulldowns or Resistance Band Pulls',
            targetMuscle: 'Latissimus Dorsi',
            sets: '3 sets',
            repsOrTime: '12 reps',
            rest: '60 sec',
            formCue: 'Pull with elbows down towards your back pockets.'
          },
          {
            name: 'Bicycle Crunches',
            targetMuscle: 'Obliques & Rectus Abdominis',
            sets: '3 sets',
            repsOrTime: '20 total alternating',
            rest: '45 sec',
            formCue: 'Slow and controlled rotation; avoid pulling on the back of neck.'
          }
        ]
      }
    ],
    sampleDaysDiet: [
      {
        dayNumber: 1,
        calorieTarget: '1,500 kcal Deficit Plan',
        breakfast: {
          veg: 'Chia Seed Pudding (25g chia in soy/skim milk) + 1 scoop plant protein + sliced kiwi.',
          nonVeg: '3 Boiled Eggs (1 whole + 2 whites) + 1 slice toasted sourdough + sliced tomatoes.',
          calories: '340 kcal | 22g Protein'
        },
        lunch: {
          veg: '1 bowl Brown Rice + 1 cup Black Chana curry + 1 cup cucumber-radish salad with lemon.',
          nonVeg: '140g Grilled Chicken Breast + 1 cup steamed green beans + 1 cup quinoa.',
          calories: '480 kcal | 34g Protein'
        },
        snacks: {
          veg: '1 cup Green Tea + 25g roasted spiced peanuts/edamame.',
          nonVeg: '1 scoop Whey isolate shaken with cold water + 1 green apple.',
          calories: '160 kcal | 15g Protein'
        },
        dinner: {
          veg: 'Low-fat paneer salad bowl with lettuce, cherry tomatoes, cucumbers & balsamic splash.',
          nonVeg: 'Baked Tilapia / Salmon fillet (150g) with grilled zucchini & bell peppers.',
          calories: '420 kcal | 31g Protein'
        },
        hydrationGoal: '3.5 Liters of water infused with mint and cucumber slices',
        keyNutritionTip: 'Prioritize protein at breakfast to suppress the hunger hormone ghrelin all afternoon.'
      }
    ]
  },
  {
    id: 'fl-muscle-gain',
    slug: 'muscle-gain',
    title: 'Hypertrophy & Muscle Gain System',
    tagline: 'Scientific Strength, Progressive Overload & Clean Mass',
    shortDesc: 'Engineered for building dense muscle tissue, increasing bench/squat/deadlift strength, and executing lean bulking protocols with zero unwanted flab.',
    duration: '90 Days (12 Weeks)',
    level: 'Intermediate to Advanced',
    price: 250,
    originalPrice: 1199,
    category: 'muscle-gain',
    badge: 'Strength Focus',
    accentColor: 'indigo',
    pdfFileName: 'FitLife_MuscleGain_Hypertrophy_Plan.pdf',
    highlights: [
      'Progressive Overload Tracking Logsheet included',
      'Push-Pull-Legs (PPL) and Upper-Lower Split Options',
      'High-Protein Muscle Synthesis Nutrition (1.8g - 2.2g per kg bodyweight)',
      'Pre & Post-Workout Nutrient Timing Blueprint',
      'Sleep & Anabolic Recovery Optimization Guide'
    ],
    benefits: [
      'Add 3–6 kg of dense muscle mass in 90 days',
      'Measurably increase compound lift strength week-over-week',
      'Enhance bone density and connective tissue resilience',
      'Master barbell, dumbbell, and bodyweight hypertrophy mechanics'
    ],
    targetAudience: [
      'Skinny individuals ("hardgainers") struggling to put on solid weight',
      'Gym-goers stuck on strength plateaus for months',
      'Fitness enthusiasts seeking athletic aesthetics and sculpted shoulders'
    ],
    sampleDaysWorkout: [
      {
        dayNumber: 1,
        dayTitle: 'Push Day: Chest, Shoulders & Triceps',
        focus: 'Hypertrophy & Mechanical Tension',
        warmUp: '7 mins: Rotator cuff warm-up, push-up walkouts, empty bar bench presses',
        coolDown: '5 mins: Pec doorway stretch, overhead tricep stretch',
        cardioStepGoal: '6,500 steps (preserve caloric surplus for muscle synthesis)',
        exercises: [
          {
            name: 'Barbell Flat Bench Press',
            targetMuscle: 'Pectoralis Major, Anterior Deltoid',
            sets: '4 sets',
            repsOrTime: '6-8 reps (heavy)',
            rest: '90-120 sec',
            formCue: 'Set scapula retracted, tuck elbows, drive feet into the floor.'
          },
          {
            name: 'Incline Dumbbell Press',
            targetMuscle: 'Clavicular Pec Head (Upper Chest)',
            sets: '3 sets',
            repsOrTime: '10-12 reps',
            rest: '90 sec',
            formCue: 'Control 3-second descent, feel full stretch at bottom before press.'
          },
          {
            name: 'Dumbbell Lateral Raises',
            targetMuscle: 'Medial Deltoid (Shoulder Width)',
            sets: '4 sets',
            repsOrTime: '12-15 reps',
            rest: '60 sec',
            formCue: 'Pour the water cue: lead with elbows, slight forward hinge.'
          },
          {
            name: 'Rope Tricep Cable Extensions',
            targetMuscle: 'Triceps Lateral & Long Head',
            sets: '3 sets',
            repsOrTime: '12-15 reps',
            rest: '60 sec',
            formCue: 'Spread rope apart at full lockout, maintain locked elbow position.'
          }
        ]
      },
      {
        dayNumber: 2,
        dayTitle: 'Pull Day: Back, Rear Delts & Biceps',
        focus: 'Lat Width, Mid-Back Thickness & Bicep Peak',
        warmUp: '7 mins: Band pull-aparts, thoracic cat-cows, light dumbbell curls',
        coolDown: '5 mins: Lat hang on pull-up bar (30s) + bicep wall stretch',
        cardioStepGoal: '6,500 steps',
        exercises: [
          {
            name: 'Conventional Deadlift or Barbell Rows',
            targetMuscle: 'Full Posterior Chain & Latissimus',
            sets: '4 sets',
            repsOrTime: '6 reps',
            rest: '2 mins',
            formCue: 'Brace core with Valsalva maneuver, drag bar along shins.'
          },
          {
            name: 'Chest-Supported Dumbbell Rows',
            targetMuscle: 'Rhomboids & Trapezius',
            sets: '3 sets',
            repsOrTime: '10-12 reps',
            rest: '90 sec',
            formCue: 'Squeeze shoulder blades together at top for a 1-second pause.'
          },
          {
            name: 'Incline Dumbbell Bicep Curls',
            targetMuscle: 'Biceps Long Head Stretch',
            sets: '3 sets',
            repsOrTime: '10-12 reps',
            rest: '60 sec',
            formCue: 'Full elbow extension at bottom without swinging shoulders.'
          }
        ]
      }
    ],
    sampleDaysDiet: [
      {
        dayNumber: 1,
        calorieTarget: '2,400 - 2,600 kcal (Clean Hypertrophic Surplus)',
        breakfast: {
          veg: 'High-Protein Smoothie: 50g oats, 1 scoop whey/plant protein, 1 banana, 2 tbsp peanut butter, whole milk + 2 whole wheat paneer parathas.',
          nonVeg: '4 Whole Eggs Omelette with cheese + 2 slices buttered multigrain toast + 1 glass orange juice.',
          calories: '650 kcal | 38g Protein'
        },
        lunch: {
          veg: '2 cups Cooked Basmati Rice + 1.5 cups Paneer Tikka Masala + 1 bowl Chana Dal + cucumber raita.',
          nonVeg: '2 cups Basmati Rice + 200g Chicken Thigh Curry cooked in ghee + 1 cup Dal + mixed salad.',
          calories: '750 kcal | 48g Protein'
        },
        snacks: {
          veg: 'Trail mix (walnuts, almonds, dates) + 1 glass thick lassi / plant protein shake.',
          nonVeg: 'Cottage cheese sandwich (2 slices bread + 80g paneer) or 3 boiled egg whites + 1 banana.',
          calories: '320 kcal | 20g Protein'
        },
        dinner: {
          veg: '3 Phulkas with ghee + 1 cup Soya Matar Curry + 1 cup Curd + roasted papad.',
          nonVeg: '3 Phulkas + 180g Grilled Fish or Mutton/Chicken keema + steamed vegetables.',
          calories: '680 kcal | 44g Protein'
        },
        hydrationGoal: '4.0 Liters daily (essential for creatine uptake and glycogen storage)',
        keyNutritionTip: 'Consume 25–35g of quality protein every 3 to 4 hours to maximize muscle protein synthesis spikes.'
      }
    ]
  },
  {
    id: 'fl-posture-correction',
    slug: 'posture-correction',
    title: 'Posture Corrector & Spine Alignment',
    tagline: 'Fix Forward Head, Rounded Shoulders & Desk Slouch',
    shortDesc: 'A physiotherapist-inspired routine to strengthen weakened back retractors, lengthen tight chest muscles, and reverse posture damage from screens.',
    duration: '30 Days (4 Weeks)',
    level: 'All Levels (Zero Equipment Needed)',
    price: 250,
    originalPrice: 899,
    category: 'posture',
    badge: 'Desk Worker Hero',
    accentColor: 'teal',
    pdfFileName: 'FitLife_Posture_Correction_Spine_Plan.pdf',
    highlights: [
      '15-Minute Daily Desk-Friendly Posture Fix Routines',
      'Targeted Upper-Crossed Syndrome Correction (Neck & Upper Back)',
      'Ergonomic Workstation Setup Checklist',
      'Deep Cervical Flexor & Lower Trap Activation Protocol',
      'Spinal Decompression & Breathing Mechanics'
    ],
    benefits: [
      'Stand taller with open, natural upright posture',
      'Alleviate chronic tension in the neck, upper trapezius, and shoulder blades',
      'Boost lung capacity and respiratory ease by opening chest wall',
      'Prevent long-term spinal disk wear and chronic slouch fatigue'
    ],
    targetAudience: [
      'Software engineers, remote workers, students sitting 8+ hours daily',
      'Anyone who notices a rounded upper back ("hunchback") or forward neck',
      'Individuals suffering from tension headaches linked to poor cervical posture'
    ],
    sampleDaysWorkout: [
      {
        dayNumber: 1,
        dayTitle: 'Neck & Upper Back Alignment Routine',
        focus: 'Cervical Retraction & Rhomboid Activation',
        warmUp: '3 mins: Gentle chin nods, side ear-to-shoulder stretches',
        coolDown: '3 mins: Prone sphinx pose, deep nasal breathing',
        cardioStepGoal: '7,000 steps with proud chest walking cue',
        exercises: [
          {
            name: 'Chin Tucks (Double Chin Drill)',
            targetMuscle: 'Deep Cervical Flexors (Longus Colli)',
            sets: '3 sets',
            repsOrTime: '12 slow reps (hold 3s)',
            rest: '30 sec',
            formCue: 'Glide chin straight backwards as if making a double chin, eyes forward.'
          },
          {
            name: 'Wall Angels',
            targetMuscle: 'Lower Trapezius & Thoracic Extension',
            sets: '3 sets',
            repsOrTime: '10 controlled reps',
            rest: '45 sec',
            formCue: 'Keep elbows, wrists, and lower back in contact with wall throughout motion.'
          },
          {
            name: 'Prone Y-T-W Raises',
            targetMuscle: 'Mid/Lower Traps & Infraspinatus',
            sets: '3 sets',
            repsOrTime: '8 reps each letter',
            rest: '45 sec',
            formCue: 'Lie on floor face down, thumbs pointing up, squeeze scapulae without shrugging.'
          },
          {
            name: 'Doorway Pectoral Stretch',
            targetMuscle: 'Pectoralis Minor & Major Lengthening',
            sets: '3 sets',
            repsOrTime: '30-45 sec hold each arm',
            rest: '30 sec',
            formCue: 'Forearm on door jamb, step gently forward until mild chest stretch is felt.'
          }
        ]
      },
      {
        dayNumber: 2,
        dayTitle: 'Pelvic & Lower Back Decompression',
        focus: 'Fixing Anterior Pelvic Tilt & Weak Glutes',
        warmUp: '3 mins: Pelvic tilts on mat, cat-cow stretches',
        coolDown: '3 mins: Child pose with arms extended',
        cardioStepGoal: '7,500 steps',
        exercises: [
          {
            name: 'Glute Bridge with 3-Second Hold',
            targetMuscle: 'Gluteus Maximus & Hamstrings',
            sets: '3 sets',
            repsOrTime: '12-15 reps',
            rest: '45 sec',
            formCue: 'Drive through heels, squeeze glutes at the top without hyperextending back.'
          },
          {
            name: 'Half-Kneeling Hip Flexor Stretch',
            targetMuscle: 'Psoas & Rectus Femoris',
            sets: '3 sets',
            repsOrTime: '45 sec each leg',
            rest: '30 sec',
            formCue: 'Tuck pelvis under (posterior tilt) and gently glide hips forward.'
          },
          {
            name: 'Bird-Dog Stability Holds',
            targetMuscle: 'Erector Spinae & Contralateral Core',
            sets: '3 sets',
            repsOrTime: '8 reps per side (hold 3s)',
            rest: '45 sec',
            formCue: 'Imagine balancing a cup of water on your lower back; no tilting.'
          }
        ]
      }
    ],
    sampleDaysDiet: [
      {
        dayNumber: 1,
        calorieTarget: 'Anti-Inflammatory Wellness Diet (1,800 kcal)',
        breakfast: {
          veg: 'Warm Turmeric & Ginger Spiced Oatmeal with walnuts, chia seeds, and berries.',
          nonVeg: '2 Soft Boiled Eggs + 1 slice sourdough with sliced avocado and black pepper.',
          calories: '360 kcal | 18g Protein'
        },
        lunch: {
          veg: '1 bowl Steamed Brown Rice + 1 cup Spinach Dal (Palak Dal) + 1 cup Raw Salad with pumpkin seeds.',
          nonVeg: '140g Steamed Salmon or Fish in ginger-garlic broth + 1 cup sauteed kale & sweet potato.',
          calories: '500 kcal | 30g Protein'
        },
        snacks: {
          veg: 'Cup of Fresh Golden Milk (Turmeric + pinch black pepper) + 6 soaked almonds.',
          nonVeg: 'Greek yogurt with cinnamon and 1 tsp honey.',
          calories: '160 kcal | 10g Protein'
        },
        dinner: {
          veg: 'Vegetable & Tofu Clear Soup with mushrooms, broccoli, and carrots + 1 small Jowar roti.',
          nonVeg: 'Grilled Chicken breast with steamed vegetable medley and light bone broth.',
          calories: '430 kcal | 32g Protein'
        },
        hydrationGoal: '3.0 Liters warm water infused with fresh ginger root',
        keyNutritionTip: 'Omega-3 fatty acids from walnuts, flaxseeds, and fatty fish dramatically accelerate connective tissue repair in overstrained tendons.'
      }
    ]
  },
  {
    id: 'fl-mobility-tightness',
    slug: 'mobility-tightness',
    title: 'Tightness & Mobility Full-Body Release',
    tagline: 'Unlock Tight Hips, Hamstrings, Shoulders & Lower Back',
    shortDesc: 'A dynamic flexibility and joint range-of-motion protocol designed to undo joint stiffness, improve athletic movement, and keep your body fluid and agile.',
    duration: '45 Days (6 Weeks)',
    level: 'Beginner to Intermediate',
    price: 250,
    originalPrice: 899,
    category: 'mobility',
    badge: 'Flexibility Focus',
    accentColor: 'cyan',
    pdfFileName: 'FitLife_Mobility_JointRelease_Plan.pdf',
    highlights: [
      'Flow-State Daily 20-Minute Mobility Sequences',
      'Targeted Hip-Opener & Hamstring Flexibility Ladders',
      'Shoulder Dislocation & Scapular Glide Exercises',
      'Foam Rolling & Self-Myofascial Release Instructions',
      'Breath-Assisted Deep Stretching Techniques'
    ],
    benefits: [
      'Touch your toes easily without lower back strain',
      'Achieve a deep, comfortable bodyweight squat',
      'Dramatically reduce morning stiffness and body aches',
      'Improve running and walking mechanics for effortless movement'
    ],
    targetAudience: [
      'Anyone feeling stiff after waking up or sitting for long hours',
      'Runners, cyclists, and weightlifters suffering from restricted hips/ankles',
      'Adults over 30 wanting to maintain youthful, supple joints'
    ],
    sampleDaysWorkout: [
      {
        dayNumber: 1,
        dayTitle: 'Hip & Lower Body Unlocking Flow',
        focus: 'Pelvic Mobility & Hamstring Lengthening',
        warmUp: '4 mins: Standing hip circles, gentle side lunges',
        coolDown: '4 mins: Legs-up-the-wall restorative relaxation',
        cardioStepGoal: '8,000 steps with brisk mindful stride',
        exercises: [
          {
            name: '90/90 Hip Mobility Switches',
            targetMuscle: 'Hip Internal & External Rotators',
            sets: '3 sets',
            repsOrTime: '8 switches per side',
            rest: '30 sec',
            formCue: 'Sit tall, both knees at 90 degrees; rotate knees across with minimal hand support.'
          },
          {
            name: 'Pigeon Pose or Figure-4 Stretch',
            targetMuscle: 'Piriformis & Glute Medius',
            sets: '3 sets',
            repsOrTime: '60 sec per leg',
            rest: '30 sec',
            formCue: 'Square hips forward, breathe deeply and allow torso to fold gently.'
          },
          {
            name: 'Cossack Squats (Supported)',
            targetMuscle: 'Adductors, Groin & Ankle Mobility',
            sets: '3 sets',
            repsOrTime: '6 reps per side',
            rest: '45 sec',
            formCue: 'Shift weight to one side while keeping straight leg heel on ground.'
          }
        ]
      }
    ],
    sampleDaysDiet: [
      {
        dayNumber: 1,
        calorieTarget: 'Hydration & Collagen-Support Nutrition (1,750 kcal)',
        breakfast: {
          veg: 'Smoothie with spinach, cucumber, chia seeds, pineapple (bromelain for recovery), and coconut water.',
          nonVeg: 'Scrambled eggs with smoked salmon / herbs + 1 whole wheat toast.',
          calories: '350 kcal | 20g Protein'
        },
        lunch: {
          veg: 'Chickpea & Quinoa Buddha Bowl with avocado, roasted carrots, and tahini dressing.',
          nonVeg: 'Lemon herb chicken with sweet potato cubes and steamed broccoli.',
          calories: '510 kcal | 32g Protein'
        },
        snacks: {
          veg: 'Handful of unsalted pumpkin seeds + 1 fresh orange (Vitamin C helps collagen synthesis).',
          nonVeg: '1 glass bone broth or protein shake with fresh berries.',
          calories: '180 kcal | 12g Protein'
        },
        dinner: {
          veg: 'Lentil stew with zucchini, bell peppers, tomatoes + 1 bajra roti.',
          nonVeg: 'Stir-fry prawns / chicken with bok choy and garlic in sesame oil.',
          calories: '440 kcal | 31g Protein'
        },
        hydrationGoal: '3.5 Liters of water with pinch of Himalayan pink salt for cellular hydration',
        keyNutritionTip: 'Joint cartilage contains 70-80% water. Dehydration immediately decreases synovial fluid cushion, exacerbating stiffness.'
      }
    ]
  },
  {
    id: 'fl-bone-joint',
    slug: 'bone-joint',
    title: 'Bone & Joint Wellness Support',
    tagline: 'Low-Impact Mobility, Joint Protection & Bone Strength',
    shortDesc: 'Gentle, zero-impact routines crafted to promote joint lubrication, bone density, and stability without placing shock on vulnerable knees or hips.',
    duration: '60 Days (8 Weeks)',
    level: 'Gentle / Senior & Beginner Friendly',
    price: 250,
    originalPrice: 799,
    category: 'general-wellness',
    badge: 'Gentle & Safe',
    accentColor: 'emerald',
    pdfFileName: 'FitLife_Bone_Joint_Support_Plan.pdf',
    highlights: [
      '100% Zero-Impact, Knee-Friendly & Lower Back-Safe Movements',
      'Synovial Fluid Activation Drills for morning stiffness',
      'Calcium, Vitamin D3 & Micronutrient Food Matrix',
      'Chair-Assisted and Standing Balance Variations',
      'Explicit Safety & Healthcare Guidance Guidelines'
    ],
    benefits: [
      'Protect knees, hips, and ankles with low-impact strengthening',
      'Improve balance, stability, and fall-prevention reflexes',
      'Support bone mineral density through safe isometric holds',
      'Enjoy comfortable, pain-free daily activities like climbing stairs'
    ],
    targetAudience: [
      'Individuals recovering from inactivity seeking safe movements',
      'Seniors or adults with sensitive knees, ankles, or wrists',
      'Anyone seeking general joint wellness without heavy impact'
    ],
    sampleDaysWorkout: [
      {
        dayNumber: 1,
        dayTitle: 'Low-Impact Joint Nourishment Circuit',
        focus: 'Knee Stabilization & Ankle Range of Motion',
        warmUp: '5 mins: Seated ankle rolls, gentle arm circles, deep belly breaths',
        coolDown: '5 mins: Seated hamstring drape, restorative breathing',
        cardioStepGoal: '5,000 gentle steps at easy conversation pace',
        exercises: [
          {
            name: 'Chair Squats (Sit-to-Stand)',
            targetMuscle: 'Quadriceps, Glutes, Functional Balance',
            sets: '3 sets',
            repsOrTime: '8-10 reps',
            rest: '60 sec',
            formCue: 'Sit down softly onto a sturdy chair, keep knees over toes, stand up pressing through heels.'
          },
          {
            name: 'Wall Push-Ups',
            targetMuscle: 'Upper Body & Wrist-Safe Chest Strengthening',
            sets: '3 sets',
            repsOrTime: '10-12 reps',
            rest: '45 sec',
            formCue: 'Hands flat against wall at shoulder height; maintain a firm, straight spine.'
          },
          {
            name: 'Seated Straight Leg Raises',
            targetMuscle: 'Vastus Medialis (Inner Knee Stabilizer)',
            sets: '3 sets',
            repsOrTime: '10 reps each leg (hold 3s)',
            rest: '45 sec',
            formCue: 'Sit upright in chair, extend leg straight out in front, flex foot toward ceiling.'
          },
          {
            name: 'Calf Raises with Wall Support',
            targetMuscle: 'Gastrocnemius & Ankle Tendons',
            sets: '3 sets',
            repsOrTime: '12-15 reps',
            rest: '45 sec',
            formCue: 'Hold wall for balance, rise smoothly onto balls of feet, hold 1s, lower slowly.'
          }
        ]
      }
    ],
    sampleDaysDiet: [
      {
        dayNumber: 1,
        calorieTarget: 'Bone & Joint Nourishment Plan (1,700 kcal)',
        breakfast: {
          veg: 'Ragi (Finger Millet) porridge cooked with milk, almonds, and jaggery (exceptionally rich in bioavailable calcium).',
          nonVeg: '2 Boiled Eggs with steamed spinach & tomatoes + 1 cup fortified milk/green tea.',
          calories: '360 kcal | 18g Protein | 420mg Calcium'
        },
        lunch: {
          veg: '1 bowl Brown Rice + 1 cup Sesame-Dal Tadka + 1 cup Sauteed Green Leafy Vegetables (Methi/Palak) + curd.',
          nonVeg: 'Grilled Sardines or Salmon (packed with natural Vitamin D & Calcium) + 1 cup brown rice & salad.',
          calories: '510 kcal | 32g Protein | 550mg Calcium'
        },
        snacks: {
          veg: '1 small bowl of roasted white sesame seeds & flaxseed brittle (chikki) or dry roasted chana.',
          nonVeg: 'Cup of warm bone broth or boiled egg white with black salt.',
          calories: '150 kcal | 9g Protein'
        },
        dinner: {
          veg: 'Steamed vegetable stew with tofu/paneer + 1 multi-grain phulka + warm turmeric milk before sleep.',
          nonVeg: 'Pan-cooked chicken with sauteed zucchini, green beans, and carrots.',
          calories: '430 kcal | 28g Protein'
        },
        hydrationGoal: '3.0 Liters of clean water + 15 minutes of safe morning sunlight exposure for Vitamin D synthesis',
        keyNutritionTip: 'Calcium requires Vitamin D3 and Magnesium for proper bone mineralization. Combine leafy greens with morning sunlight.'
      }
    ]
  }
];

export const TRANSFORMATION_STORIES = [
  {
    name: 'Rahul Sharma',
    age: 34,
    plan: '90-Day Fat to Fit Challenge',
    loss: '-11.5 kg in 90 Days',
    quote: 'As a tech manager working 10 hours at a desk, I had developed stubborn belly fat and awful upper back pain. The ₹250 FitLife PDF plan gave me structured 40-minute home workouts and a delicious Indian meal plan. I dropped 11.5 kg and my posture is completely transformed!',
    startingWeight: '88 kg',
    currentWeight: '76.5 kg',
    waistReduction: '-4.5 inches'
  },
  {
    name: 'Priya Iyer',
    age: 29,
    plan: 'Posture Corrector & Fat Loss',
    loss: '-8.2 kg & Fixed Tech-Neck',
    quote: 'The free preview convinced me, and buying the complete plan for ₹250 was the best investment of the year. The double chin drills and wall angels completely got rid of my daily neck tension. I feel lighter, taller, and much more energetic.',
    startingWeight: '69 kg',
    currentWeight: '60.8 kg',
    waistReduction: '-3.8 inches'
  },
  {
    name: 'Vikram Patel',
    age: 41,
    plan: 'Bone & Joint + Mobility Program',
    loss: 'Zero Knee Pain & +50% Mobility',
    quote: 'I had been afraid to exercise because of sensitive knees. FitLife’s low-impact plan gave me safe chair squats and gentle mobility flows that strengthened the muscles around my knees without any pain. Highly recommended!',
    startingWeight: '82 kg',
    currentWeight: '75 kg',
    waistReduction: '-3.0 inches'
  }
];

export const FREQUENTLY_ASKED_QUESTIONS = [
  {
    q: 'How do I receive my plan after paying ₹250?',
    a: 'Instant digital delivery! Immediately upon successful payment via UPI (GPay, PhonePe, Paytm), Card, or NetBanking, your plan is instantly unlocked on your screen, in your "My Account" area, and on the "Download Plans" page. You can download your high-resolution printable PDF with one click anytime.'
  },
  {
    q: 'Do I need expensive gym equipment to do these workouts?',
    a: 'No! Every FitLife plan is engineered with dual tracks: bodyweight & resistance band variations for home training, and dumbbell/barbell variations for gym enthusiasts. You can start in your living room today.'
  },
  {
    q: 'Are the diet charts suitable for Indian vegetarians?',
    a: 'Yes, absolutely. FitLife features 100% authentic, wholesome Indian vegetarian meal charts (incorporating moong dal, paneer, sprouts, chana, millets, dahi, and seasonal vegetables) alongside high-protein non-vegetarian variations.'
  },
  {
    q: 'Can I do the 90-day challenge if I have never worked out before?',
    a: 'Yes. The 90-Day Challenge is broken into three 30-day progressive phases: Phase 1 builds your foundation and movement mechanics; Phase 2 introduces fat-burning volume; Phase 3 locks in definition and permanent habits.'
  },
  {
    q: 'What is your safety and medical policy?',
    a: 'FitLife plans provide general fitness, exercise, and nutrition education for healthy individuals and do NOT constitute medical advice, physical therapy, or diagnostic prescription. Anyone with medical conditions, cardiovascular issues, joint pain, pregnancy, or chronic ailments must consult their physician prior to starting.'
  },
  {
    q: 'Can I download the plan on my smartphone?',
    a: 'Yes! The PDF is fully optimized for reading on iPhones, Android smartphones, iPads/tablets, laptops, and desktop screens, or printing out to stick on your refrigerator.'
  }
];
