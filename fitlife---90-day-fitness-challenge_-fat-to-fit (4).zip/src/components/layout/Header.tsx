import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Page } from '../../types';
import { FitLifeLogo } from '../common/FitLifeLogo';
import { ShoppingBag, User, Menu, X, ChevronDown, Download, Calculator } from 'lucide-react';

export const Header: React.FC = () => {
  const { currentPage, setCurrentPage, cartCount, purchasedProgramIds, setIsBmiModalOpen } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [programsDropdownOpen, setProgramsDropdownOpen] = useState(false);

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    setProgramsDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const programSublinks = [
    { label: '90-Day Fat to Fit Challenge', page: '90-day-challenge' as Page },
    { label: 'Fat Loss Accelerator', page: 'fat-loss' as Page },
    { label: 'Muscle Gain System', page: 'muscle-gain' as Page },
    { label: 'Posture Corrector Program', page: 'posture-correction' as Page },
    { label: 'Tightness & Mobility Program', page: 'mobility-tightness' as Page },
    { label: 'Bone & Joint Support', page: 'bone-joint' as Page }
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Zone 1: Single text element Brand mark */}
          <button
            onClick={() => navigateTo('home')}
            className="flex items-center text-left focus:outline-hidden group"
          >
            <FitLifeLogo size="md" />
          </button>

          {/* Zone 2: 4-6 Clean text navigation links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-semibold text-slate-700">
            <button
              onClick={() => navigateTo('home')}
              className={`transition-colors hover:text-emerald-600 ${
                currentPage === 'home' ? 'text-emerald-600 font-bold' : ''
              }`}
            >
              Home
            </button>

            <button
              onClick={() => navigateTo('90-day-challenge')}
              className={`transition-colors hover:text-emerald-600 ${
                currentPage === '90-day-challenge' ? 'text-emerald-600 font-bold' : ''
              }`}
            >
              90-Day Challenge
            </button>

            {/* Programs Dropdown */}
            <div className="relative group">
              <button
                onClick={() => setProgramsDropdownOpen(!programsDropdownOpen)}
                className={`flex items-center gap-1 transition-colors hover:text-emerald-600 ${
                  [
                    'fat-loss',
                    'muscle-gain',
                    'posture-correction',
                    'mobility-tightness',
                    'bone-joint'
                  ].includes(currentPage)
                    ? 'text-emerald-600 font-bold'
                    : ''
                }`}
              >
                <span>Programs</span>
                <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:rotate-180" />
              </button>

              <div className="absolute left-0 top-full pt-2 w-64 hidden group-hover:block transition-all">
                <div className="bg-white rounded-xl shadow-xl border border-slate-200 p-2 space-y-1">
                  {programSublinks.map((sub) => (
                    <button
                      key={sub.page}
                      onClick={() => navigateTo(sub.page)}
                      className="w-full text-left px-3 py-2 text-xs font-medium text-slate-700 hover:text-emerald-600 hover:bg-emerald-50/80 rounded-lg transition-colors"
                    >
                      {sub.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={() => navigateTo('shop')}
              className={`transition-colors hover:text-emerald-600 ${
                currentPage === 'shop' ? 'text-emerald-600 font-bold' : ''
              }`}
            >
              Plans (₹250)
            </button>

            <button
              onClick={() => navigateTo('download-plans')}
              className={`flex items-center gap-1.5 transition-colors hover:text-emerald-600 ${
                currentPage === 'download-plans' ? 'text-emerald-600 font-bold' : ''
              }`}
            >
              <span>Download Plans</span>
              {purchasedProgramIds.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              )}
            </button>

            <button
              onClick={() => navigateTo('about')}
              className={`transition-colors hover:text-emerald-600 ${
                currentPage === 'about' ? 'text-emerald-600 font-bold' : ''
              }`}
            >
              About
            </button>

            <button
              onClick={() => navigateTo('faq')}
              className={`transition-colors hover:text-emerald-600 ${
                currentPage === 'faq' ? 'text-emerald-600 font-bold' : ''
              }`}
            >
              FAQ
            </button>
          </nav>

          {/* Zone 3: 1-2 Primary Actions */}
          <div className="flex items-center gap-3">
            {/* Quick Calorie Tool */}
            <button
              onClick={() => setIsBmiModalOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-emerald-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              title="Calorie & BMI Calculator"
            >
              <Calculator className="w-3.5 h-3.5 text-emerald-600" />
              <span>Calculator</span>
            </button>

            {/* Cart Icon */}
            <button
              onClick={() => navigateTo('cart')}
              className="relative p-2.5 text-slate-700 hover:text-emerald-600 hover:bg-slate-100 rounded-lg transition-colors"
              aria-label="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-emerald-600 text-white font-bold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                  {cartCount}
                </span>
              )}
            </button>

            {/* My Account */}
            <button
              onClick={() => navigateTo('my-account')}
              className="hidden md:flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <User className="w-4 h-4 text-emerald-600" />
              <span>My Account</span>
            </button>

            {/* Primary CTA */}
            <button
              onClick={() => navigateTo('shop')}
              className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-emerald-600 rounded-lg transition-colors whitespace-nowrap shadow-xs"
            >
              Buy Plan – ₹250
            </button>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-emerald-600 lg:hidden"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3">
          <div className="flex flex-col space-y-1">
            <button
              onClick={() => navigateTo('home')}
              className="text-left px-3 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50 rounded-lg"
            >
              Home
            </button>
            <button
              onClick={() => navigateTo('90-day-challenge')}
              className="text-left px-3 py-2 text-sm font-semibold text-emerald-600 hover:bg-emerald-50 rounded-lg"
            >
              90-Day Fat to Fit Challenge
            </button>
            <div className="pl-3 border-l-2 border-slate-200 my-1 space-y-1">
              {programSublinks.map((sub) => (
                <button
                  key={sub.page}
                  onClick={() => navigateTo(sub.page)}
                  className="text-left block w-full px-3 py-1.5 text-xs text-slate-600 hover:text-emerald-600"
                >
                  {sub.label}
                </button>
              ))}
            </div>
            <button
              onClick={() => navigateTo('shop')}
              className="text-left px-3 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50 rounded-lg"
            >
              Shop All Plans (₹250)
            </button>
            <button
              onClick={() => navigateTo('download-plans')}
              className="text-left px-3 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50 rounded-lg flex items-center justify-between"
            >
              <span>Download Plans (PDF Vault)</span>
              {purchasedProgramIds.length > 0 && (
                <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                  {purchasedProgramIds.length} Unlocked
                </span>
              )}
            </button>
            <button
              onClick={() => navigateTo('my-account')}
              className="text-left px-3 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50 rounded-lg"
            >
              My Account
            </button>
            <button
              onClick={() => navigateTo('about')}
              className="text-left px-3 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50 rounded-lg"
            >
              About FitLife
            </button>
            <button
              onClick={() => navigateTo('faq')}
              className="text-left px-3 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50 rounded-lg"
            >
              FAQ
            </button>
            <button
              onClick={() => navigateTo('contact')}
              className="text-left px-3 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50 rounded-lg"
            >
              Contact Support
            </button>
          </div>

          <div className="pt-3 border-t border-slate-200 flex flex-col gap-2">
            <button
              onClick={() => {
                setIsBmiModalOpen(true);
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 bg-slate-100 text-slate-800 font-semibold text-xs rounded-lg flex items-center justify-center gap-2"
            >
              <Calculator className="w-4 h-4 text-emerald-600" />
              <span>Calorie & BMI Calculator</span>
            </button>

            <button
              onClick={() => navigateTo('shop')}
              className="w-full py-2.5 bg-emerald-600 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-2"
            >
              <span>Start 90-Day Challenge – ₹250</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
