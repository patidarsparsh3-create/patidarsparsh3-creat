import React from 'react';
import { useApp } from '../../context/AppContext';
import { Page } from '../../types';
import { FitLifeLogo } from '../common/FitLifeLogo';
import { ShieldCheck, Download, Heart } from 'lucide-react';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const Footer: React.FC = () => {
  const { setCurrentPage } = useApp();

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-900 mt-20">
      {/* Pre-footer Safety Notice */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-6">
        <MedicalDisclaimer variant="compact" className="bg-slate-900 text-amber-200 border-slate-800" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <FitLifeLogo size="md" inverted />
            <p className="text-xs sm:text-sm text-slate-400 max-w-sm leading-relaxed">
              FitLife is an evidence-based health and wellness community committed to empowering individuals across India to achieve real fat loss, lean muscle definition, functional mobility, and lifelong vitality through structured 90-day protocols.
            </p>

            <div className="pt-2 flex items-center gap-3 text-xs text-slate-400">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>100% Secure Instant Digital Delivery · Protected PDF Vault</span>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Accepted Payments:</span>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                <span className="bg-slate-900 border border-slate-800 px-2 py-1 rounded">UPI / GPay</span>
                <span className="bg-slate-900 border border-slate-800 px-2 py-1 rounded">PhonePe</span>
                <span className="bg-slate-900 border border-slate-800 px-2 py-1 rounded">Paytm</span>
                <span className="bg-slate-900 border border-slate-800 px-2 py-1 rounded">Cards</span>
              </div>
            </div>
          </div>

          {/* Programs */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Training Programs
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-400">
              <li>
                <button
                  onClick={() => navigateTo('90-day-challenge')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  90-Day Fat to Fit Challenge
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('fat-loss')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Fat Loss Accelerator
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('muscle-gain')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Muscle Gain Hypertrophy
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('posture-correction')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Posture Corrector & Spine
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('mobility-tightness')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Tightness & Mobility Release
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('bone-joint')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Bone & Joint Support
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Store Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Digital Store & PDFs
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-400">
              <li>
                <button
                  onClick={() => navigateTo('shop')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  All Plans (₹250 Each)
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('download-plans')}
                  className="hover:text-emerald-400 transition-colors flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download Plans Vault</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('cart')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  View Cart
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('checkout')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Secure Checkout
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('my-account')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  My Account & Orders
                </button>
              </li>
            </ul>
          </div>

          {/* Company & Support */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Support & Community
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-400">
              <li>
                <button
                  onClick={() => navigateTo('about')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  About FitLife
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('faq')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('contact')}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Contact Support
                </button>
              </li>
            </ul>

            <div className="pt-2 text-xs text-slate-400 space-y-1.5">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Instant Digital Access & Download Delivery</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} FitLife Health & Wellness Community. All rights reserved.
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Powered by WooCommerce & FitLife Engine</span>
            <span>·</span>
            <span>Made with <Heart className="w-3 h-3 inline text-red-500 fill-current" /> for Indian Fitness</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
