import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FREQUENTLY_ASKED_QUESTIONS } from '../../data/programsData';
import { ChevronDown, HelpCircle, ArrowRight } from 'lucide-react';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const FAQPage: React.FC = () => {
  const { setCurrentPage } = useApp();
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIdx(openIdx === idx ? null : idx);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      <div className="text-center space-y-3">
        <div className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
          Got Questions?
        </div>
        <h1 className="text-3xl sm:text-4xl font-black font-display text-slate-900 tracking-tight">
          Frequently Asked Questions
        </h1>
        <p className="text-sm text-slate-600">
          Everything you need to know about our ₹250 downloadable diet and workout plans.
        </p>
      </div>

      <MedicalDisclaimer variant="compact" />

      {/* Accordion */}
      <div className="space-y-3">
        {FREQUENTLY_ASKED_QUESTIONS.map((item, idx) => {
          const isOpen = openIdx === idx;
          return (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs transition-colors"
            >
              <button
                onClick={() => toggle(idx)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-sm sm:text-base text-slate-900 hover:text-emerald-700 transition-colors"
              >
                <span className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-emerald-50 text-emerald-800 text-xs flex items-center justify-center shrink-0">
                    Q
                  </span>
                  <span>{item.q}</span>
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-slate-400 shrink-0 transition-transform ${
                    isOpen ? 'rotate-180 text-emerald-600' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 bg-slate-50/50">
                  {item.a}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom CTA */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="font-bold text-base text-white">Have a specific question?</h3>
          <p className="text-xs text-slate-400">Our fitness coaching and support team is here to assist you anytime.</p>
        </div>
        <button
          onClick={() => setCurrentPage('contact')}
          className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors whitespace-nowrap"
        >
          Contact Support
        </button>
      </div>
    </div>
  );
};
