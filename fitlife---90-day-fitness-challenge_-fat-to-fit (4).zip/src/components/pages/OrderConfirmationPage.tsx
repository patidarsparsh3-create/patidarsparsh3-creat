import React from 'react';
import { useApp } from '../../context/AppContext';
import { PROGRAMS } from '../../data/programsData';
import { CheckCircle2, Download, ArrowRight, ShieldCheck, FileText, User } from 'lucide-react';
import { generatePlanPDF } from '../../utils/pdfGenerator';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const OrderConfirmationPage: React.FC = () => {
  const { currentOrder, orders, setCurrentPage, user, showToast } = useApp();

  // Fallback to latest order if available
  const order = currentOrder || orders[0];

  if (!order) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-2xl font-bold font-display text-slate-900">
          No Recent Order Found
        </h2>
        <p className="text-xs sm:text-sm text-slate-600">
          You can check your unlocked downloads or browse plans in the store.
        </p>
        <button
          onClick={() => setCurrentPage('shop')}
          className="px-6 py-2.5 bg-emerald-600 text-white font-bold text-xs rounded-xl"
        >
          Go to Plans (₹250)
        </button>
      </div>
    );
  }

  const handleDownload = (programId: string) => {
    const program = PROGRAMS.find((p) => p.id === programId);
    if (!program) return;
    try {
      generatePlanPDF(program, order.customerName, order.orderId);
      showToast(`Downloading "${program.title}" official PDF...`);
    } catch (err) {
      console.error(err);
      showToast('Error generating PDF.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Thank you Banner */}
      <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-6 sm:p-10 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto shadow-md">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <div className="space-y-1">
          <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest">
            Payment Confirmed · Instant Unlock
          </span>
          <h1 className="text-2xl sm:text-4xl font-black font-display text-slate-900">
            Thank you! Your FitLife Plan is Ready.
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto leading-relaxed">
            Your payment was completed successfully. Your downloadable plan PDFs have been permanently unlocked below and in your account vault.
          </p>
        </div>
      </div>

      {/* Order Summary Metadata Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs sm:text-sm divide-y sm:divide-y-0 sm:divide-x divide-slate-100">
        <div className="space-y-1">
          <span className="text-slate-400 text-xs uppercase font-semibold">Order Number:</span>
          <div className="font-bold text-slate-900 font-display text-base">
            {order.orderId}
          </div>
        </div>
        <div className="space-y-1 pt-2 sm:pt-0 sm:pl-4">
          <span className="text-slate-400 text-xs uppercase font-semibold">Date:</span>
          <div className="font-semibold text-slate-800">
            {order.date}
          </div>
        </div>
        <div className="space-y-1 pt-2 sm:pt-0 sm:pl-4">
          <span className="text-slate-400 text-xs uppercase font-semibold">Total Paid:</span>
          <div className="font-bold text-emerald-700 text-base tabular-nums">
            ₹{order.total}
          </div>
        </div>
        <div className="space-y-1 pt-2 sm:pt-0 sm:pl-4">
          <span className="text-slate-400 text-xs uppercase font-semibold">Payment Method:</span>
          <div className="font-semibold text-slate-800">
            {order.paymentMethod}
          </div>
        </div>
      </div>

      {/* Unlocked Protected Downloads Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2">
            <Download className="w-5 h-5 text-emerald-600" />
            <h2 className="text-lg font-bold text-slate-900 font-display">
              Unlocked Digital Downloads
            </h2>
          </div>
          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded">
            Lifetime Access Active
          </span>
        </div>

        <div className="space-y-4">
          {order.items.map((item) => (
            <div
              key={item.programId}
              className="p-5 rounded-xl border border-emerald-200 bg-emerald-50/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-700" />
                  <h3 className="font-bold text-sm sm:text-base text-slate-900">
                    {item.title}
                  </h3>
                </div>
                <p className="text-xs text-slate-600">
                  Full 90-Day Diet & Exercise Blueprint PDF with Indian vegetarian & non-veg charts
                </p>
                <div className="text-[11px] text-slate-500">
                  License: {order.customerName} · Order {order.orderId}
                </div>
              </div>

              <button
                onClick={() => handleDownload(item.programId)}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm shrink-0 active:scale-98"
              >
                <Download className="w-4 h-4" />
                <span>Download PDF</span>
              </button>
            </div>
          ))}
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 border-t border-slate-100">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Files are encrypted with your license name and date</span>
          </div>

          <button
            onClick={() => setCurrentPage('download-plans')}
            className="text-emerald-700 font-semibold hover:underline"
          >
            Go to Protected Downloads Vault →
          </button>
        </div>
      </div>

      {/* Safety Notice */}
      <MedicalDisclaimer variant="compact" />

      {/* Action buttons */}
      <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
        <button
          onClick={() => setCurrentPage('my-account')}
          className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors flex items-center gap-2"
        >
          <User className="w-4 h-4 text-emerald-400" />
          <span>View My Account & Orders</span>
        </button>
        <button
          onClick={() => setCurrentPage('home')}
          className="px-6 py-3 border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs rounded-xl transition-colors"
        >
          Back to Homepage
        </button>
      </div>
    </div>
  );
};
