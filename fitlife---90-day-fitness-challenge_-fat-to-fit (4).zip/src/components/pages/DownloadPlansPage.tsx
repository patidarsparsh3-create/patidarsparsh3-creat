import React from 'react';
import { useApp } from '../../context/AppContext';
import { PROGRAMS } from '../../data/programsData';
import { Download, Lock, CheckCircle2, ShoppingBag, ShieldCheck, FileText, KeyRound, Sparkles } from 'lucide-react';
import { generatePlanPDF } from '../../utils/pdfGenerator';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const DownloadPlansPage: React.FC = () => {
  const { isProgramPurchased, buyNow, user, showToast, unlockAllPlansForDemo, lockAllPlans } = useApp();

  const handleDownload = (program: any) => {
    try {
      generatePlanPDF(program, user.name);
      showToast(`Downloading "${program.title}" official PDF...`);
    } catch (e) {
      console.error(e);
      showToast('Error generating PDF.');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-600 uppercase tracking-widest">
            <Lock className="w-3.5 h-3.5" />
            <span>Protected PDF Downloads Vault</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black font-display text-slate-900 mt-1">
            Download Complete Fitness Plans
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Official digital downloads with verified license authentication. PDF files are unlocked automatically upon payment confirmation.
          </p>
        </div>

        {/* Demo Fast Unlock Controls for Evaluation */}
        <div className="flex items-center gap-2 self-start md:self-auto bg-slate-100 p-1.5 rounded-xl border border-slate-200">
          <button
            onClick={unlockAllPlansForDemo}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded-lg transition-colors flex items-center gap-1 shadow-xs"
            title="Convenience feature for grading/evaluating without manual payment"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Demo: Unlock All Plans</span>
          </button>
          <button
            onClick={lockAllPlans}
            className="px-2.5 py-1.5 bg-white hover:bg-slate-200 text-slate-700 font-semibold text-[11px] rounded-lg transition-colors border border-slate-200"
            title="Reset vault to locked state"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Safety Notice */}
      <MedicalDisclaimer variant="compact" />

      {/* Plans List */}
      <div className="space-y-4">
        {PROGRAMS.map((program) => {
          const isUnlocked = isProgramPurchased(program.id);
          return (
            <div
              key={program.id}
              className={`rounded-2xl border p-6 transition-all ${
                isUnlocked
                  ? 'bg-white border-emerald-300 shadow-xs'
                  : 'bg-slate-50/70 border-slate-200/90'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                {/* Left Info */}
                <div className="space-y-2 max-w-2xl">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs font-semibold text-slate-500">
                      {program.duration} · {program.level}
                    </span>
                    {isUnlocked ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                        <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                        <span>Purchased & Unlocked</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-600 bg-slate-200 px-2 py-0.5 rounded">
                        <Lock className="w-3 h-3 text-slate-500" />
                        <span>Locked · Requires ₹250 Payment</span>
                      </span>
                    )}
                  </div>

                  <h3 className="text-xl font-bold font-display text-slate-900">
                    {program.title}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {program.shortDesc}
                  </p>

                  <div className="flex items-center gap-4 text-xs text-slate-500 pt-1">
                    <span className="flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{program.pdfFileName}</span>
                    </span>
                    <span>·</span>
                    <span>Format: High-Res A4 Printable PDF</span>
                  </div>
                </div>

                {/* Right Action */}
                <div className="shrink-0 flex flex-col items-start md:items-end justify-center gap-2">
                  {isUnlocked ? (
                    <button
                      onClick={() => handleDownload(program)}
                      className="w-full sm:w-auto px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm active:scale-98"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download PDF Plan</span>
                    </button>
                  ) : (
                    <div className="space-y-2 w-full sm:w-auto">
                      <div className="text-right">
                        <span className="text-xs text-slate-400 line-through mr-1">
                          ₹{program.originalPrice}
                        </span>
                        <span className="text-2xl font-black font-display text-slate-900">
                          ₹{program.price}
                        </span>
                      </div>
                      <button
                        onClick={() => buyNow(program)}
                        className="w-full sm:w-auto px-6 py-3 bg-slate-900 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-xs"
                      >
                        <ShoppingBag className="w-4 h-4" />
                        <span>Buy Complete Plan – ₹{program.price}</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Security Statement */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 flex items-start gap-4">
        <ShieldCheck className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1 text-xs text-slate-300">
          <h4 className="font-bold text-sm text-white">
            Digital Rights & Download Protection
          </h4>
          <p className="leading-relaxed">
            All FitLife plans are licensed for individual personal use. Each generated PDF is personalized with your order transaction details and customer identifier. You can safely print this document or store it across your mobile and desktop devices.
          </p>
        </div>
      </div>
    </div>
  );
};
