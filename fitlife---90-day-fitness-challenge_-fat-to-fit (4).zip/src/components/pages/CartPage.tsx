import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Trash2, ArrowRight, ShoppingBag, ShieldCheck, Tag, ChevronLeft } from 'lucide-react';

export const CartPage: React.FC = () => {
  const { cart, removeFromCart, cartTotal, setCurrentPage, couponCode, setCouponCode, applyCoupon, discountAmount, couponMessage } = useApp();
  const [couponInput, setCouponInput] = useState(couponCode || '');

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    applyCoupon(couponInput);
  };

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold font-display text-slate-900">
            Your Cart is Currently Empty
          </h2>
          <p className="text-sm text-slate-600 max-w-md mx-auto">
            Choose a 90-day transformation plan or targeted posture routine to get started. All plans are ₹250 with instant digital PDF access.
          </p>
        </div>
        <button
          onClick={() => setCurrentPage('shop')}
          className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl inline-flex items-center gap-2 transition-colors"
        >
          <span>Return to Shop</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black font-display text-slate-900">
            Shopping Cart
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            WooCommerce Digital Products (Instant Automated Delivery)
          </p>
        </div>
        <button
          onClick={() => setCurrentPage('shop')}
          className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Continue Shopping</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Cart Items Table */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="bg-slate-50 px-6 py-3 border-b border-slate-200 text-xs font-bold text-slate-600 uppercase tracking-wider grid grid-cols-12">
              <span className="col-span-7">Product</span>
              <span className="col-span-2 text-right">Price</span>
              <span className="col-span-3 text-right">Action</span>
            </div>

            <div className="divide-y divide-slate-200">
              {cart.map((item) => (
                <div key={item.programId} className="px-6 py-4 grid grid-cols-12 items-center gap-2">
                  <div className="col-span-7">
                    <h3 className="font-bold text-sm text-slate-900">
                      {item.title}
                    </h3>
                    <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded">
                      Complete Diet + Exercise Plan PDF
                    </span>
                  </div>

                  <div className="col-span-2 text-right font-bold text-sm text-slate-900 tabular-nums">
                    ₹{item.price}
                  </div>

                  <div className="col-span-3 text-right">
                    <button
                      onClick={() => removeFromCart(item.programId)}
                      className="text-xs text-red-600 hover:text-red-700 p-1.5 rounded-lg hover:bg-red-50 transition-colors inline-flex items-center gap-1 font-semibold"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Remove</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Coupon Code Strip */}
            <div className="bg-slate-50/70 p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <form onSubmit={handleApplyCoupon} className="flex items-center gap-2 w-full sm:w-auto">
                <div className="relative">
                  <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Coupon code (e.g. FITLIFE50)"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    className="pl-8 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-colors whitespace-nowrap"
                >
                  Apply
                </button>
              </form>

              {couponMessage && (
                <div className="text-xs font-semibold text-emerald-700">
                  {couponMessage}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>256-Bit Encrypted Payments · Protected PDF Download Delivery</span>
          </div>
        </div>

        {/* Cart Totals Box */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
          <h3 className="font-bold text-base text-slate-900 uppercase tracking-wide border-b border-slate-100 pb-3">
            Cart Totals
          </h3>

          <div className="space-y-3 text-xs sm:text-sm">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal:</span>
              <span className="font-semibold text-slate-900 tabular-nums">₹{subtotal}</span>
            </div>

            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>Coupon Discount:</span>
                <span className="tabular-nums">- ₹{discountAmount}</span>
              </div>
            )}

            <div className="flex justify-between text-slate-600">
              <span>Digital Delivery:</span>
              <span className="text-emerald-700 font-semibold">FREE (Instant Unlock)</span>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-between items-baseline">
              <span className="font-bold text-base text-slate-900">Total:</span>
              <span className="font-black text-2xl font-display text-slate-900 tabular-nums">
                ₹{cartTotal}
              </span>
            </div>
          </div>

          <button
            onClick={() => setCurrentPage('checkout')}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm active:scale-98"
          >
            <span>Proceed to Checkout</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
