import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Lock, CreditCard, QrCode, CheckCircle2, ArrowRight, Smartphone, Building, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';
import QRCode from 'qrcode';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';
import { PROGRAMS } from '../../data/programsData';
import { trackInitiateCheckout, trackAddPaymentInfo } from '../../utils/metaPixel';

export const CheckoutPage: React.FC = () => {
  const { cart, cartTotal, createOrder, setCurrentPage, user, showToast, setThankYouProgram } = useApp();

  const [name, setName] = useState(user.name || '');
  const [email, setEmail] = useState(user.email || '');
  const [phone, setPhone] = useState(user.phone || '');
  const [fitnessGoal, setFitnessGoal] = useState('90-Day Fat Loss & Body Recomposition');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [utrNumber, setUtrNumber] = useState('');
  const [cardNumber, setCardNumber] = useState('4111 ···· ···· 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvv, setCardCvv] = useState('888');
  const [agreeTerms, setAgreeTerms] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  const receiverUpi = 'fitlife.wellness@ybl';

  // Fire Meta Pixel InitiateCheckout with real customer data
  useEffect(() => {
    trackInitiateCheckout({
      value: cartTotal,
      num_items: cart.length,
      content_ids: cart.map((c) => c.programId),
      currency: 'INR',
      customer: { name, email, phone }
    });
  }, []);

  const selectPaymentMethod = (method: 'upi' | 'card' | 'netbanking') => {
    setPaymentMethod(method);
    trackAddPaymentInfo({
      payment_type: method,
      value: cartTotal,
      currency: 'INR',
      customer: { name, email, phone }
    });
  };

  useEffect(() => {
    const upiPayload = `upi://pay?pa=${receiverUpi}&pn=FitLife%20Health&am=${cartTotal}&cu=INR&tn=FitLife_Order`;
    const canvas = document.createElement('canvas');
    canvas.width = 360;
    canvas.height = 360;

    QRCode.toCanvas(
      canvas,
      upiPayload,
      {
        width: 360,
        margin: 2,
        errorCorrectionLevel: 'H',
        color: { dark: '#000000', light: '#ffffff' }
      },
      (err) => {
        if (err) return;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const cx = canvas.width / 2;
          const cy = canvas.height / 2;
          const r = 34;
          // Outer white circle
          ctx.beginPath();
          ctx.arc(cx, cy, r + 4, 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.fill();
          // Inner PhonePe dark circle
          ctx.beginPath();
          ctx.arc(cx, cy, r, 0, Math.PI * 2);
          ctx.fillStyle = '#1c1c1e';
          ctx.fill();
          // White 'पे'
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 38px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('पे', cx, cy + 2);
        }
        setQrDataUrl(canvas.toDataURL('image/png'));
      }
    );
  }, [cartTotal]);

  if (cart.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-2xl font-bold font-display text-slate-900">
          Your Cart is Empty
        </h2>
        <p className="text-xs sm:text-sm text-slate-600">
          Please add a plan to your cart before proceeding to checkout.
        </p>
        <button
          onClick={() => setCurrentPage('shop')}
          className="px-6 py-3 bg-emerald-600 text-white font-bold text-xs rounded-xl"
        >
          Browse Plans (₹250)
        </button>
      </div>
    );
  }

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreeTerms) {
      showToast('Please agree to the digital delivery terms.');
      return;
    }

    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      const order = createOrder({
        method: paymentMethod.toUpperCase(),
        name,
        email,
        phone
      });

      // Find primary purchased program for thank you modal
      const firstProgram = PROGRAMS.find((p) => p.id === cart[0]?.programId) || PROGRAMS[0];

      // Confetti celebration
      try {
        confetti({
          particleCount: 90,
          spread: 75,
          origin: { y: 0.5 }
        });
      } catch (err) {
        console.error(err);
      }

      showToast(`Payment successful! Order ${order.orderId} confirmed.`);
      setCurrentPage('order-confirmation');
      setThankYouProgram(firstProgram);
    }, 1100);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Checkout Title */}
      <div>
        <h1 className="text-2xl sm:text-4xl font-black font-display text-slate-900">
          WooCommerce Checkout
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Indian Payment Gateway Integration · Instant Automated PDF Unlock
        </p>
      </div>

      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Customer Billing Details */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900 uppercase tracking-wide border-b border-slate-100 pb-3">
              1. Customer & Delivery Information
            </h2>

            <div className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Full Name (For PDF License) *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Member Name"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Primary Transformation Goal
                </label>
                <select
                  value={fitnessGoal}
                  onChange={(e) => setFitnessGoal(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden text-xs sm:text-sm"
                >
                  <option>90-Day Fat Loss & Body Recomposition</option>
                  <option>Muscle Hypertrophy & Progressive Strength</option>
                  <option>Posture Correction (Desk Slouch & Neck Relief)</option>
                  <option>Joint Mobility & Flexibility Enhancement</option>
                  <option>Low-Impact Bone & Joint Longevity</option>
                </select>
              </div>
            </div>
          </div>

          {/* Payment Method Selector (India Appropriate) */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900 uppercase tracking-wide border-b border-slate-100 pb-3 flex items-center justify-between">
              <span>2. Payment Option (India Gateway)</span>
              <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded">
                Secured by Razorpay / UPI
              </span>
            </h2>

            <div className="space-y-3">
              {/* Option 1: UPI */}
              <div
                onClick={() => selectPaymentMethod('upi')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'upi'
                    ? 'border-emerald-600 bg-emerald-50/40 ring-1 ring-emerald-600'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'upi'}
                      onChange={() => selectPaymentMethod('upi')}
                      className="accent-emerald-600 w-4 h-4"
                    />
                    <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-emerald-600" />
                      <span>UPI (GPay / PhonePe / Paytm / BHIM)</span>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                    Fastest
                  </span>
                </div>

                {paymentMethod === 'upi' && (
                  <div className="mt-4 pt-4 border-t border-emerald-100 space-y-4 text-xs">
                    {/* QR Code Graphic Frame */}
                    <div className="flex flex-col sm:flex-row items-center gap-5 bg-white p-4 rounded-xl border border-slate-200">
                      <div className="relative p-2 bg-white border-2 border-slate-900 rounded-xl shadow-xs shrink-0">
                        {qrDataUrl ? (
                          <img
                            src={qrDataUrl}
                            alt="PhonePe Payment Scanner"
                            className="w-36 h-36 object-contain"
                          />
                        ) : (
                          <div className="w-36 h-36 flex items-center justify-center bg-slate-100">
                            <RefreshCw className="w-6 h-6 text-slate-400 animate-spin" />
                          </div>
                        )}
                        {/* Corner markers */}
                        <div className="absolute top-1 left-1 w-3 h-3 border-t-2 border-l-2 border-emerald-600" />
                        <div className="absolute top-1 right-1 w-3 h-3 border-t-2 border-r-2 border-emerald-600" />
                        <div className="absolute bottom-1 left-1 w-3 h-3 border-b-2 border-l-2 border-emerald-600" />
                        <div className="absolute bottom-1 right-1 w-3 h-3 border-b-2 border-r-2 border-emerald-600" />
                      </div>

                      <div className="space-y-2 text-center sm:text-left">
                        <div className="font-bold text-slate-900 text-sm">
                          Scan to Pay ₹{cartTotal}
                        </div>
                        <p className="text-slate-600 text-xs">
                          Open PhonePe, GPay, Paytm or BHIM on your phone and point camera at this QR code.
                        </p>
                        <div className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1 rounded-md inline-block">
                          Instant verification & automated PDF download
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        12-Digit Transaction Ref No. / UTR (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. 12-digit UPI reference number"
                        value={utrNumber}
                        onChange={(e) => setUtrNumber(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden tabular-nums font-mono"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Option 2: Card */}
              <div
                onClick={() => selectPaymentMethod('card')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'card'
                    ? 'border-emerald-600 bg-emerald-50/40 ring-1 ring-emerald-600'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'card'}
                      onChange={() => selectPaymentMethod('card')}
                      className="accent-emerald-600 w-4 h-4"
                    />
                    <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-slate-700" />
                      <span>Credit / Debit Card (RuPay / Visa / Mastercard)</span>
                    </div>
                  </div>
                </div>

                {paymentMethod === 'card' && (
                  <div className="mt-4 pt-3 border-t border-emerald-100 space-y-3 text-xs">
                    <div>
                      <label className="block text-slate-600 mb-1">Card Number</label>
                      <input
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white tabular-nums"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-slate-600 mb-1">Valid Thru</label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={(e) => setCardExpiry(e.target.value)}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white tabular-nums"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-600 mb-1">CVV</label>
                        <input
                          type="password"
                          value={cardCvv}
                          onChange={(e) => setCardCvv(e.target.value)}
                          className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white tabular-nums"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Option 3: NetBanking */}
              <div
                onClick={() => selectPaymentMethod('netbanking')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  paymentMethod === 'netbanking'
                    ? 'border-emerald-600 bg-emerald-50/40 ring-1 ring-emerald-600'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="paymentMethod"
                    checked={paymentMethod === 'netbanking'}
                    onChange={() => selectPaymentMethod('netbanking')}
                    className="accent-emerald-600 w-4 h-4"
                  />
                  <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <Building className="w-4 h-4 text-slate-700" />
                    <span>Net Banking (SBI, HDFC, ICICI, Axis & All Major Banks)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Medical Notice */}
          <MedicalDisclaimer variant="compact" />
        </div>

        {/* Right: Order Summary & Place Order */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <h2 className="text-base font-bold text-slate-900 uppercase tracking-wide border-b border-slate-100 pb-3">
            Your Order
          </h2>

          <div className="divide-y divide-slate-100 text-xs sm:text-sm">
            {cart.map((item) => (
              <div key={item.programId} className="py-3 flex justify-between items-center gap-3">
                <div>
                  <div className="font-bold text-slate-900">{item.title}</div>
                  <div className="text-[11px] text-slate-500">
                    High-Res Printable PDF Blueprint
                  </div>
                </div>
                <div className="font-bold text-slate-900 tabular-nums shrink-0">
                  ₹{item.price}
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-200 space-y-2 text-xs sm:text-sm">
            <div className="flex justify-between text-slate-600">
              <span>Delivery Format:</span>
              <span className="font-semibold text-emerald-700">Protected PDF Download</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Access Duration:</span>
              <span className="font-semibold text-slate-800">Lifetime Re-Download</span>
            </div>
            <div className="pt-3 border-t border-slate-200 flex justify-between items-baseline">
              <span className="font-bold text-base text-slate-900">Total Payable:</span>
              <span className="font-black text-3xl font-display text-slate-900 tabular-nums">
                ₹{cartTotal}
              </span>
            </div>
          </div>

          {/* Terms checkbox */}
          <label className="flex items-start gap-2.5 text-xs text-slate-600 cursor-pointer pt-2">
            <input
              type="checkbox"
              checked={agreeTerms}
              onChange={(e) => setAgreeTerms(e.target.checked)}
              className="mt-0.5 accent-emerald-600 w-4 h-4 rounded"
            />
            <span className="leading-relaxed">
              I agree to the digital delivery terms (Note: do exercise according to your pain, don't over stretch).
            </span>
          </label>

          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-xl flex items-center justify-center gap-2 transition-all shadow-md active:scale-98 disabled:opacity-75"
          >
            {isProcessing ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Processing Payment...</span>
              </span>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>Pay & Unlock Plan – ₹{cartTotal}</span>
              </>
            )}
          </button>

          <div className="text-center text-[11px] text-slate-400 space-y-1">
            <p>100% Secure Checkout · Instant Download Access</p>
            <p>Order receipt and license key generated immediately.</p>
          </div>
        </div>
      </form>
    </div>
  );
};
