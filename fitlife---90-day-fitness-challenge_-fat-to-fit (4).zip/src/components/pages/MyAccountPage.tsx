import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PROGRAMS } from '../../data/programsData';
import { Package, Download, Settings, ShieldCheck, Database, RefreshCw, Copy, CheckCircle2 } from 'lucide-react';
import { generatePlanPDF } from '../../utils/pdfGenerator';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const MyAccountPage: React.FC = () => {
  const {
    user,
    orders,
    purchasedProgramIds,
    setCurrentPage,
    showToast,
    supabaseStatus,
    supabaseProjectId,
    syncOrdersWithSupabase
  } = useApp();

  const [activeTab, setActiveTab] = useState<'downloads' | 'orders' | 'database' | 'profile'>('downloads');
  const [copiedSql, setCopiedSql] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const purchasedPrograms = PROGRAMS.filter((p) => purchasedProgramIds.includes(p.id));

  const handleDownload = (program: any) => {
    generatePlanPDF(program, user.name);
    showToast(`Downloading "${program.title}" PDF...`);
  };

  const handleSync = async () => {
    setIsSyncing(true);
    await syncOrdersWithSupabase();
    setIsSyncing(false);
  };

  const sqlSchema = `-- Supabase SQL Schema for FitLife Plan Purchases
CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  subtotal NUMERIC(10,2) NOT NULL DEFAULT 250,
  discount NUMERIC(10,2) NOT NULL DEFAULT 0,
  total NUMERIC(10,2) NOT NULL DEFAULT 250,
  payment_method TEXT NOT NULL DEFAULT 'UPI',
  payment_status TEXT NOT NULL DEFAULT 'completed',
  transaction_id TEXT NOT NULL,
  fitness_goal TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security (RLS)
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Allow public insert and read for customer orders
CREATE POLICY "Allow public insert to orders" ON orders
  FOR INSERT TO public WITH CHECK (true);

CREATE POLICY "Allow public read from orders" ON orders
  FOR SELECT TO public USING (true);`;

  const copySql = () => {
    navigator.clipboard.writeText(sqlSchema);
    setCopiedSql(true);
    showToast('Supabase SQL schema copied to clipboard!');
    setTimeout(() => setCopiedSql(false), 2500);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* User Header Profile Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-bold text-xl font-display shadow-md">
            {user.name.charAt(0)}
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
                {user.name}
              </h1>
              <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                FitLife Member
              </span>
            </div>
            <div className="text-xs font-semibold text-slate-700">
              Primary Goal: {user.fitnessGoal}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentPage('shop')}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
          >
            Browse Plans (₹250)
          </button>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex items-center border-b border-slate-200 gap-6 text-sm font-semibold overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('downloads')}
          className={`pb-3 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'downloads'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Download className="w-4 h-4" />
          <span>My Plan Downloads ({purchasedPrograms.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-3 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'orders'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Order History ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('database')}
          className={`pb-3 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'database'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Database className="w-4 h-4" />
          <span className="flex items-center gap-1.5">
            <span>Supabase Cloud DB</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-3 border-b-2 transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'profile'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Account Details</span>
        </button>
      </div>

      {/* Tab 1: Downloads */}
      {activeTab === 'downloads' && (
        <div className="space-y-4">
          {purchasedPrograms.length === 0 ? (
            <div className="bg-slate-50 rounded-2xl border border-slate-200 p-12 text-center space-y-4">
              <Download className="w-12 h-12 text-slate-400 mx-auto" />
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-slate-800">
                  No Purchased Plans Yet
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
                  When you purchase any ₹250 diet & exercise plan, your automated download links will appear here permanently.
                </p>
              </div>
              <button
                onClick={() => setCurrentPage('shop')}
                className="px-6 py-2.5 bg-emerald-600 text-white font-bold text-xs rounded-xl"
              >
                Explore ₹250 Plans
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {purchasedPrograms.map((prog) => (
                <div
                  key={prog.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                        Active PDF License
                      </span>
                      <span className="text-xs font-bold text-slate-900">₹{prog.price}</span>
                    </div>
                    <h4 className="font-bold text-base text-slate-900 pt-1 font-display">
                      {prog.title}
                    </h4>
                    <p className="text-xs text-slate-600 line-clamp-2">
                      {prog.shortDesc}
                    </p>
                  </div>

                  <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                    <span className="text-xs text-slate-500 font-medium">
                      High-Res Printable
                    </span>
                    <button
                      onClick={() => handleDownload(prog)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs active:scale-98"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download PDF</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Orders */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-bold text-base text-slate-900">
              Purchased Plan Invoices ({orders.length})
            </h3>
            <span className="text-xs text-slate-500">
              Instant WooCommerce Order Generation
            </span>
          </div>

          {orders.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No orders found. Buy your first plan to start tracking!
            </div>
          ) : (
            <div className="space-y-3">
              {orders.map((o) => (
                <div
                  key={o.orderId}
                  className="p-4 rounded-xl border border-slate-100 hover:border-slate-200 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 font-display">
                        #{o.orderId}
                      </span>
                      <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded uppercase">
                        {o.paymentStatus}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        Via {o.paymentMethod}
                      </span>
                    </div>
                    <div className="text-slate-600">
                      {o.items.map((i) => i.title).join(', ')}
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      {o.date} · Txn: {o.transactionId}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-black text-base text-slate-900 tabular-nums">
                      ₹{o.total}
                    </div>
                    <button
                      onClick={() => setCurrentPage('download-plans')}
                      className="text-xs font-bold text-emerald-600 hover:underline mt-1 inline-block"
                    >
                      Access Downloads →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Supabase Cloud Database */}
      {activeTab === 'database' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-lg text-slate-900 font-display">
                  Supabase Database Integration
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Connected to project ID: <strong className="font-mono text-slate-800">{supabaseProjectId}</strong>
              </p>
            </div>

            <button
              onClick={handleSync}
              disabled={isSyncing}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-all shadow-xs disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Syncing...' : 'Sync Database Now'}</span>
            </button>
          </div>

          {/* Connection status card */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <div className="text-xs">
              <span className="font-bold text-emerald-950 block">
                Supabase Client Active
              </span>
              <span className="text-emerald-800">
                {supabaseStatus?.message || `Connected to Supabase project "${supabaseProjectId}" with live publishable key.`}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
              <span className="text-slate-500 text-[11px] uppercase font-semibold">Project ID</span>
              <div className="font-mono font-bold text-slate-900">{supabaseProjectId}</div>
            </div>
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
              <span className="text-slate-500 text-[11px] uppercase font-semibold">Orders Synced</span>
              <div className="font-bold text-slate-900 text-base">{orders.length} Purchases</div>
            </div>
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
              <span className="text-slate-500 text-[11px] uppercase font-semibold">Automatic Mode</span>
              <div className="font-bold text-emerald-700 text-base">Realtime on Checkout</div>
            </div>
          </div>

          {/* SQL Setup Instruction Block */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                  Supabase SQL Table Definition
                </h4>
                <p className="text-[11px] text-slate-500">
                  Run this in your Supabase SQL Editor if the <code className="font-mono text-emerald-700">orders</code> table is not yet created:
                </p>
              </div>
              <button
                onClick={copySql}
                className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors"
              >
                {copiedSql ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy SQL</span>
                  </>
                )}
              </button>
            </div>

            <pre className="p-4 bg-slate-900 text-slate-100 rounded-xl text-[11px] font-mono overflow-x-auto leading-relaxed border border-slate-800">
              {sqlSchema}
            </pre>
          </div>
        </div>
      )}

      {/* Tab 4: Profile Settings */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6 max-w-2xl">
          <h3 className="font-bold text-base text-slate-900 border-b border-slate-100 pb-3">
            Personal & Health Preferences
          </h3>
          <div className="space-y-4 text-xs sm:text-sm">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Member Name (on PDF License)</label>
              <input
                type="text"
                disabled
                value={user.name}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Primary Fitness Goal</label>
              <input
                type="text"
                disabled
                value={user.fitnessGoal}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 cursor-not-allowed"
              />
            </div>
          </div>
        </div>
      )}

      {/* Safety Notice */}
      <MedicalDisclaimer variant="compact" />
    </div>
  );
};
