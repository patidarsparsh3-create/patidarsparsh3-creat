import React, { useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { PROGRAMS } from '../../data/programsData';
import { InteractiveChart } from '../common/InteractiveChart';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';
import { generatePlanPDF } from '../../utils/pdfGenerator';
import { trackViewContent, trackCustomEvent } from '../../utils/metaPixel';
import { CheckCircle2, Download, ShoppingBag, ShieldCheck, Flame, Calendar, Trophy, ArrowRight, Zap, Droplets, Utensils, Dumbbell, QrCode } from 'lucide-react';

export const NinetyDayChallengePage: React.FC = () => {
  const { buyNow, isProgramPurchased, user, showToast, setScannerProgram } = useApp();
  const program = PROGRAMS[0]; // 90-day challenge
  const isPurchased = isProgramPurchased(program.id);

  useEffect(() => {
    trackViewContent({
      content_name: program.title,
      content_category: '90-Day Challenge',
      content_ids: [program.id],
      value: program.price,
      currency: 'INR'
    });
  }, [program.id, program.title, program.price]);

  const handleDownload = () => {
    trackCustomEvent('DownloadPlan', {
      program_id: program.id,
      program_title: program.title
    });
    generatePlanPDF(program, user.name);
    showToast(`Downloading official "${program.title}" PDF...`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Hero Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-10 lg:p-12 relative overflow-hidden border border-slate-800">
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-widest">
            <Flame className="w-4 h-4" />
            <span>Flagship Transformation Program</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black font-display tracking-tight text-white">
            90-Day Fat to Fit Complete Challenge
          </h1>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            A comprehensive 12-week body transformation protocol designed to shed stubborn body fat, build functional muscle, correct desk-slouch posture, and instill lasting nutrition discipline.
          </p>

          <div className="pt-4 flex flex-wrap items-center gap-4">
            {isPurchased ? (
              <button
                onClick={handleDownload}
                className="px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl flex items-center gap-2 transition-all shadow-lg active:scale-98"
              >
                <Download className="w-5 h-5" />
                <span>Download Purchased Plan PDF</span>
              </button>
            ) : (
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setScannerProgram(program)}
                  className="px-7 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl flex items-center gap-2 transition-all shadow-lg active:scale-98"
                >
                  <QrCode className="w-5 h-5" />
                  <span>Scan QR to Pay (₹250)</span>
                </button>
                <button
                  onClick={() => buyNow(program)}
                  className="px-6 py-4 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl flex items-center gap-2 transition-all border border-slate-700"
                >
                  <ShoppingBag className="w-5 h-5 text-emerald-400" />
                  <span>Card / NetBanking Checkout</span>
                </button>
              </div>
            )}

            <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-800/80 px-4 py-3 rounded-xl border border-slate-700">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Instant Automated Access · Printable PDF Format</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mandatory Safety Notice */}
      <MedicalDisclaimer />

      {/* The 3-Phase Transformation Matrix */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-black font-display text-slate-900">
            The 90-Day Progression Architecture
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Why random gym workouts fail: without phased progressive overload, your metabolism adapts and fat loss stalls. Here is how our 90 days are calibrated:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Phase 1 */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center">
                P1
              </span>
              <span className="text-xs font-semibold text-slate-500">Days 1–30</span>
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Prime, Posture & Metabolic Ignition
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              We activate dormant scapular and pelvic stabilizers, prime the digestive system with an anti-inflammatory Indian meal template, establish 3.5L hydration, and introduce foundational compound movements.
            </p>
            <ul className="text-xs text-slate-600 space-y-1.5 pt-2 border-t border-slate-100">
              <li>• Focus: Neuromuscular form & daily habit lock</li>
              <li>• Cardio: 8,000 steps baseline</li>
              <li>• Calorie Target: 300 kcal moderate deficit</li>
            </ul>
          </div>

          {/* Phase 2 */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-7 h-7 rounded-lg bg-teal-100 text-teal-800 font-bold text-xs flex items-center justify-center">
                P2
              </span>
              <span className="text-xs font-semibold text-slate-500">Days 31–60</span>
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Overload & Rapid Fat Oxidation
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Workout density increases. We introduce supersets, low-impact HIIT finishers, and progressive resistance to burn through visceral fat stores while sculpting dense muscle definition.
            </p>
            <ul className="text-xs text-slate-600 space-y-1.5 pt-2 border-t border-slate-100">
              <li>• Focus: Progressive resistance & core hardening</li>
              <li>• Cardio: 10,000 steps daily target</li>
              <li>• Calorie Target: 500 kcal sustained deficit</li>
            </ul>
          </div>

          {/* Phase 3 */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-800 font-bold text-xs flex items-center justify-center">
                P3
              </span>
              <span className="text-xs font-semibold text-slate-500">Days 61–90</span>
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Peak Tone, Mobility & Lifestyle Lock
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              We fine-tune muscle definition, eliminate lingering postural tightness in hips and neck, and transition your nutrition into a sustainable maintenance blueprint so the weight stays off forever.
            </p>
            <ul className="text-xs text-slate-600 space-y-1.5 pt-2 border-t border-slate-100">
              <li>• Focus: Muscle retention, joint fluidity & maintenance</li>
              <li>• Cardio: 9,000 steps + active recovery walks</li>
              <li>• Calorie Target: Reverse dieting calibration</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Free Interactive Chart Preview */}
      <section className="space-y-4">
        <div>
          <h2 className="text-2xl font-bold font-display text-slate-900">
            Free Preview: Day-by-Day Workout & Diet Chart
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Below is a sample of Days 1 through 3 from the 90-day plan. The full PDF unlocks all 90 days with daily variations, progression logs, and grocery lists.
          </p>
        </div>

        <InteractiveChart
          workoutDays={program.sampleDaysWorkout}
          dietDays={program.sampleDaysDiet}
          programTitle={program.title}
        />
      </section>

      {/* Pricing / Buy Now Card */}
      <div className="bg-slate-900 text-white rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-800">
        <div className="space-y-2">
          <div className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
            Complete Digital Download
          </div>
          <h3 className="text-2xl sm:text-3xl font-bold font-display">
            Unlock the Full 90-Day Fat to Fit Blueprint PDF
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Get the full 90-day exercise progression charts, vegetarian & non-vegetarian meal plans, posture drills, and habit tracking sheets.
          </p>
        </div>

        <div className="text-center md:text-right shrink-0 space-y-3">
          <div className="flex items-baseline justify-center md:justify-end gap-2">
            <span className="text-sm text-slate-400 line-through">₹1,499</span>
            <span className="text-4xl font-black font-display text-white">₹250</span>
          </div>

          {isPurchased ? (
            <button
              onClick={handleDownload}
              className="px-8 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-md w-full sm:w-auto"
            >
              <Download className="w-5 h-5" />
              <span>Download PDF</span>
            </button>
          ) : (
            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                onClick={() => setScannerProgram(program)}
                className="px-6 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <QrCode className="w-4 h-4" />
                <span>Scan QR Code – ₹250</span>
              </button>
              <button
                onClick={() => buyNow(program)}
                className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all border border-slate-700"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Regular Checkout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
