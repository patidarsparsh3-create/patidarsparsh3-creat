import React from 'react';
import { useApp } from '../../context/AppContext';
import { PROGRAMS, TRANSFORMATION_STORIES } from '../../data/programsData';
import { Program } from '../../types';
import { ArrowRight, CheckCircle2, ShieldCheck, Flame, Dumbbell, Sparkles, Activity, FileText, Download, Trophy, Target, HeartPulse, ChevronRight, Zap, QrCode } from 'lucide-react';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const HomePage: React.FC = () => {
  const { setCurrentPage, setPreviewProgram, buyNow, isProgramPurchased, setIsBmiModalOpen, setScannerProgram } = useApp();

  const handleProgramDetail = (slug: string) => {
    setCurrentPage(slug as any);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-16 sm:space-y-24">
      {/* ============================================================== */}
      {/* 1. MAIN HERO SECTION                                          */}
      {/* ============================================================== */}
      <section className="relative overflow-hidden pt-8 pb-16 md:pt-14 md:pb-24 bg-linear-to-b from-slate-900 via-slate-900 to-slate-950 text-white">
        {/* Subtle grid backdrop */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#10B981_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Value Prop & CTAs */}
            <div className="lg:col-span-7 space-y-6">
              {/* Unboxed natural kicker */}
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-widest">
                <Flame className="w-4 h-4 text-emerald-400" />
                <span>The Definitive Indian Body Transformation Protocol</span>
              </div>

              {/* Exact Mandated Headline */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-display tracking-tight text-white leading-[1.08] text-balance">
                90 Days. One Goal. <br />
                <span className="text-transparent bg-clip-text bg-linear-to-r from-emerald-400 via-teal-300 to-emerald-200">
                  Fat to Fit.
                </span>
              </h1>

              {/* Exact Mandated Subheading */}
              <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
                Transform your body with structured workouts, nutrition guidance, posture exercises, and a 90-day fitness roadmap.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => setCurrentPage('90-day-challenge')}
                  className="px-7 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl flex items-center gap-2 transition-all shadow-lg hover:shadow-emerald-500/25 active:scale-98"
                >
                  <span>Start 90-Day Challenge</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setScannerProgram(PROGRAMS[0])}
                  className="px-6 py-3.5 bg-slate-800/90 hover:bg-slate-700 text-emerald-400 hover:text-white font-bold rounded-xl flex items-center gap-2 transition-all border border-emerald-500/30 active:scale-98"
                >
                  <QrCode className="w-4 h-4 text-emerald-400" />
                  <span>Scan QR to Pay (₹250)</span>
                </button>

                <button
                  onClick={() => setCurrentPage('shop')}
                  className="px-6 py-3.5 bg-transparent hover:bg-slate-800/60 text-slate-300 font-semibold rounded-xl flex items-center gap-1.5 transition-all border border-slate-700 active:scale-98"
                >
                  <span>Explore Plans</span>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-4 grid grid-cols-3 gap-4 border-t border-slate-800/80 text-xs sm:text-sm">
                <div>
                  <div className="text-xl sm:text-2xl font-black font-display text-white tabular-nums">
                    ₹250
                  </div>
                  <div className="text-slate-400 text-xs mt-0.5">
                    Complete Plan PDF
                  </div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black font-display text-emerald-400 tabular-nums">
                    12 Weeks
                  </div>
                  <div className="text-slate-400 text-xs mt-0.5">
                    Phased Roadmap
                  </div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black font-display text-teal-400 tabular-nums">
                    100%
                  </div>
                  <div className="text-slate-400 text-xs mt-0.5">
                    Veg & Non-Veg Diet
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Fitness Transformation Visual & 90-Day Concept */}
            <div className="lg:col-span-5">
              <div className="relative bg-slate-800/60 border border-slate-700/80 rounded-2xl p-6 sm:p-7 shadow-2xl backdrop-blur-xs">
                {/* Header card badge */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-amber-400" />
                    <span className="font-bold text-sm text-white">90-Day Transformation Matrix</span>
                  </div>
                  <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2.5 py-0.5 rounded">
                    Proven Blueprint
                  </span>
                </div>

                {/* Interactive 3-Phase Roadmap Visual */}
                <div className="py-5 space-y-4">
                  {/* Phase 1 */}
                  <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700 flex items-start gap-3.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center shrink-0">
                      P1
                    </div>
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-white flex items-center justify-between">
                        <span>Days 1–30: Prime & Metabolic Reset</span>
                        <span className="text-[10px] text-emerald-400">Baseline Form</span>
                      </div>
                      <p className="text-xs text-slate-400">
                        Activate dormant stabilizer muscles, eliminate sugar cravings, and build 3.5L hydration habit.
                      </p>
                    </div>
                  </div>

                  {/* Phase 2 */}
                  <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700 flex items-start gap-3.5">
                    <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 font-bold text-xs flex items-center justify-center shrink-0">
                      P2
                    </div>
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-white flex items-center justify-between">
                        <span>Days 31–60: Strength & Fat Oxidation</span>
                        <span className="text-[10px] text-teal-400">Overload</span>
                      </div>
                      <p className="text-xs text-slate-400">
                        Accelerate progressive overload, tighten core, and reduce subcutaneous belly fat.
                      </p>
                    </div>
                  </div>

                  {/* Phase 3 */}
                  <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700 flex items-start gap-3.5">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 font-bold text-xs flex items-center justify-center shrink-0">
                      P3
                    </div>
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-white flex items-center justify-between">
                        <span>Days 61–90: Peak Tone & Habit Mastery</span>
                        <span className="text-[10px] text-amber-400">Results</span>
                      </div>
                      <p className="text-xs text-slate-400">
                        Sculpt defined physique, correct posture imbalances, and lock in lifetime fitness stamina.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Instant Plan Preview action */}
                <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between">
                  <div className="text-xs text-slate-300">
                    Includes Printable Day-by-Day Charts
                  </div>
                  <button
                    onClick={() => setPreviewProgram(PROGRAMS[0])}
                    className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition-colors"
                  >
                    <span>Free Preview</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Safety Notice Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <MedicalDisclaimer variant="banner" className="rounded-xl border shadow-xs" />
      </div>

      {/* ============================================================== */}
      {/* 2. MAIN PROGRAMS SECTION (5 DEDICATED PROGRAMS)               */}
      {/* ============================================================== */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
            Structured Transformations
          </div>
          <h2 className="text-3xl sm:text-4xl font-black font-display text-slate-900 tracking-tight">
            Targeted Fitness & Nutrition Programs
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            Every FitLife program includes step-by-step workout splits, dual vegetarian & non-veg meal plans, progressive charts, and instant printable PDF downloads for ₹250.
          </p>
        </div>

        {/* 5 Dedicated Program Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROGRAMS.map((program) => {
            const isPurchased = isProgramPurchased(program.id);
            return (
              <div
                key={program.id}
                className="bg-white rounded-2xl border border-slate-200/90 hover:border-slate-300 p-6 flex flex-col justify-between shadow-xs hover:shadow-md transition-all group"
              >
                <div>
                  {/* Category & Badge */}
                  <div className="flex items-center justify-between text-xs mb-3">
                    <span className="font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md">
                      {program.duration}
                    </span>
                    {program.badge && (
                      <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                        {program.badge}
                      </span>
                    )}
                  </div>

                  {/* Title & Tagline */}
                  <h3 className="text-xl font-bold font-display text-slate-900 group-hover:text-emerald-700 transition-colors">
                    {program.title}
                  </h3>
                  <p className="text-xs font-semibold text-slate-500 mt-1">
                    {program.tagline}
                  </p>
                  <p className="text-xs text-slate-600 mt-2.5 leading-relaxed line-clamp-3">
                    {program.shortDesc}
                  </p>

                  {/* Highlights list */}
                  <div className="mt-4 pt-4 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                    {program.highlights.slice(0, 3).map((h, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{h}</span>
                      </div>
                    ))}
                  </div>

                  {/* Special Bone & Joint note */}
                  {program.category === 'general-wellness' && (
                    <div className="mt-3 text-[11px] text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-200/60 leading-tight">
                      *General wellness guidance, not medical treatment.
                    </div>
                  )}
                </div>

                {/* Price & Action Area */}
                <div className="mt-6 pt-4 border-t border-slate-100 space-y-3">
                  <div className="flex items-baseline justify-between">
                    <div>
                      <span className="text-xs text-slate-400 line-through mr-1.5">
                        ₹{program.originalPrice}
                      </span>
                      <span className="text-2xl font-black font-display text-slate-900">
                        ₹{program.price}
                      </span>
                    </div>
                    <span className="text-xs font-bold text-emerald-700">
                      Complete Plan PDF
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setPreviewProgram(program)}
                      className="w-full py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-colors text-center"
                    >
                      Free Preview
                    </button>

                    {isPurchased ? (
                      <button
                        onClick={() => setCurrentPage('download-plans')}
                        className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => setScannerProgram(program)}
                        className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>Scan & Pay ₹{program.price}</span>
                      </button>
                    )}
                  </div>

                  {!isPurchased && (
                    <button
                      onClick={() => buyNow(program)}
                      className="w-full py-2 border border-slate-200 hover:border-slate-300 text-slate-700 text-xs font-semibold rounded-lg flex items-center justify-center gap-1 transition-colors"
                    >
                      <span>Add to Cart / Regular Checkout</span>
                      <ArrowRight className="w-3 h-3 text-slate-400" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ============================================================== */}
      {/* 3. FREE PREVIEW SYSTEM TEASER BANNER                          */}
      {/* ============================================================== */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <div className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
                Try Before You Commit
              </div>
              <h3 className="text-2xl sm:text-3xl font-black font-display">
                Inspect 3 Days of Workouts & Meals for Free
              </h3>
              <p className="text-sm text-slate-300 max-w-xl leading-relaxed">
                See exactly how our daily exercise reps, form cues, warm-up routines, and vegetarian or non-vegetarian meal plans are laid out before purchasing the full 90-day blueprint for ₹250.
              </p>
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => setPreviewProgram(PROGRAMS[0])}
                  className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-2 transition-colors"
                >
                  <FileText className="w-4 h-4" />
                  <span>Launch Free Interactive Preview</span>
                </button>
                <button
                  onClick={() => setIsBmiModalOpen(true)}
                  className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 transition-colors border border-slate-700"
                >
                  <Activity className="w-4 h-4 text-emerald-400" />
                  <span>Calculate Calorie Deficit</span>
                </button>
              </div>
            </div>

            <div className="lg:col-span-4 bg-slate-800/80 rounded-2xl p-6 border border-slate-700 text-center space-y-3">
              <div className="text-xs uppercase font-bold text-slate-400">
                Unlock Complete 90-Day Plan PDF
              </div>
              <div className="text-4xl font-black font-display text-white">
                ₹250 <span className="text-xs text-slate-400 font-normal">one-time</span>
              </div>
              <p className="text-xs text-slate-300">
                Automatic instant download access unlocked immediately upon UPI, PhonePe, GPay, or Card checkout.
              </p>
              <button
                onClick={() => setScannerProgram(PROGRAMS[0])}
                className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-1.5"
              >
                <QrCode className="w-4 h-4" />
                <span>Scan QR Code to Pay – ₹250</span>
              </button>
              <button
                onClick={() => buyNow(PROGRAMS[0])}
                className="w-full py-2.5 bg-slate-700/80 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl transition-colors"
              >
                Regular Checkout (Card / NetBanking)
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* 4. REAL TRANSFORMATION PROOF & STORIES                        */}
      {/* ============================================================== */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-12">
          <div className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
            Community Milestones
          </div>
          <h2 className="text-3xl font-black font-display text-slate-900 tracking-tight">
            Real People. 90-Day Transformations.
          </h2>
          <p className="text-sm text-slate-600">
            Disciplined daily execution with FitLife’s structured Indian nutrition and progressive home/gym training.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TRANSFORMATION_STORIES.map((story, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col justify-between shadow-xs"
            >
              <div className="space-y-4">
                {/* Result Pill */}
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-md">
                    {story.loss}
                  </span>
                  <span className="text-xs text-emerald-700 font-semibold">
                    Verified Member
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed italic">
                  "{story.quote}"
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{story.name}</h4>
                  <div className="text-xs text-slate-500">
                    Age {story.age} · {story.plan}
                  </div>
                </div>
                <div className="text-right text-xs">
                  <div className="font-bold text-slate-900">{story.currentWeight}</div>
                  <div className="text-[11px] text-slate-400">From {story.startingWeight}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ============================================================== */}
      {/* 5. FINAL CONVERSION CALL TO ACTION                            */}
      {/* ============================================================== */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-linear-to-r from-emerald-600 to-teal-700 text-white rounded-3xl p-8 sm:p-14 text-center space-y-6 shadow-xl">
          <div className="inline-block bg-white/20 backdrop-blur-xs text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
            Start Your Day 1 Tomorrow Morning
          </div>
          <h2 className="text-3xl sm:text-5xl font-black font-display text-white max-w-2xl mx-auto tracking-tight">
            Stop Guessing in the Gym. Get the 90-Day Blueprint.
          </h2>
          <p className="text-sm sm:text-base text-emerald-50 max-w-xl mx-auto leading-relaxed">
            Join thousands following FitLife’s structured fat loss, muscle building, and posture restoration protocols. Lifetime digital access for only ₹250.
          </p>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => buyNow(PROGRAMS[0])}
              className="px-8 py-4 bg-slate-950 hover:bg-slate-900 text-white font-black text-sm rounded-xl flex items-center gap-2 transition-all shadow-lg active:scale-98"
            >
              <span>Buy Complete Plan – ₹250</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentPage('shop')}
              className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold text-sm rounded-xl transition-all border border-white/30"
            >
              <span>View All 5 Plans</span>
            </button>
          </div>

          <div className="flex items-center justify-center gap-6 pt-4 text-xs text-emerald-100">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-white" />
              Instant Download After Payment
            </span>
            <span className="hidden sm:inline">·</span>
            <span className="hidden sm:inline">All UPI & Cards Accepted</span>
          </div>
        </div>
      </section>
    </div>
  );
};
