import React, { useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Program } from '../../types';
import { InteractiveChart } from '../common/InteractiveChart';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';
import { generatePlanPDF } from '../../utils/pdfGenerator';
import { trackViewContent, trackCustomEvent } from '../../utils/metaPixel';
import { CheckCircle2, Download, ShoppingBag, ShieldCheck, ArrowRight, Sparkles, AlertTriangle, QrCode } from 'lucide-react';

interface ProgramDetailPageProps {
  program: Program;
}

export const ProgramDetailPage: React.FC<ProgramDetailPageProps> = ({ program }) => {
  const { buyNow, isProgramPurchased, user, showToast, setScannerProgram } = useApp();
  const isPurchased = isProgramPurchased(program.id);

  // Track Meta Pixel ViewContent
  useEffect(() => {
    trackViewContent({
      content_name: program.title,
      content_category: program.category || 'Fitness & Diet Plans',
      content_ids: [program.id],
      value: program.price,
      currency: 'INR'
    });
  }, [program.id, program.title, program.price]);

  const handleDownload = () => {
    trackCustomEvent('DownloadPlan', {
      program_id: program.id,
      program_title: program.title
    });
    generatePlanPDF(program, user.name);
    showToast(`Downloading official "${program.title}" PDF...`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Hero Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-10 lg:p-12 relative overflow-hidden border border-slate-800">
        <div className="max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-widest">
            <span>{program.duration} · {program.level}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black font-display tracking-tight text-white">
            {program.title}
          </h1>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            {program.shortDesc}
          </p>

          <div className="pt-4 flex flex-wrap items-center gap-4">
            {isPurchased ? (
              <button
                onClick={handleDownload}
                className="px-8 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl flex items-center gap-2 transition-all shadow-lg active:scale-98"
              >
                <Download className="w-5 h-5" />
                <span>Download Purchased PDF</span>
              </button>
            ) : (
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setScannerProgram(program)}
                  className="px-7 py-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl flex items-center gap-2 transition-all shadow-lg active:scale-98"
                >
                  <QrCode className="w-5 h-5" />
                  <span>Scan QR to Pay (₹{program.price})</span>
                </button>
                <button
                  onClick={() => buyNow(program)}
                  className="px-6 py-4 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl flex items-center gap-2 transition-all border border-slate-700"
                >
                  <ShoppingBag className="w-5 h-5 text-emerald-400" />
                  <span>Regular Checkout</span>
                </button>
              </div>
            )}

            <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-800/80 px-4 py-3 rounded-xl border border-slate-700">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Instant Digital Unlock · High-Res Printable Format</span>
            </div>
          </div>
        </div>
      </div>

      {/* Special Medical Statement for Bone & Joint / General Wellness */}
      {program.category === 'general-wellness' ? (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-6 flex items-start gap-4">
          <AlertTriangle className="w-6 h-6 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs sm:text-sm text-amber-950">
            <h3 className="font-bold text-base text-amber-900">
              General Wellness Information Notice
            </h3>
            <p className="leading-relaxed">
              <strong>Important Notice:</strong> This Bone & Joint Support program provides general fitness, low-impact mobility, and nutritional wellness education only. It is <strong>NOT medical treatment, physical therapy, orthopedic rehabilitation, or diagnosis</strong>. If you suffer from osteoarthritis, torn ligaments, severe joint degeneration, or chronic pain, always consult your physician or orthopedic specialist before beginning any exercise regimen.
            </p>
          </div>
        </div>
      ) : (
        <MedicalDisclaimer />
      )}

      {/* Program Benefits & What's Included */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-4 shadow-xs">
          <h2 className="text-xl font-bold font-display text-slate-900 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-600" />
            <span>Key Benefits You Will Achieve</span>
          </h2>
          <ul className="space-y-3 text-xs sm:text-sm text-slate-600">
            {program.benefits.map((benefit, i) => (
              <li key={i} className="flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{benefit}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-4 shadow-xs">
          <h2 className="text-xl font-bold font-display text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <span>Complete Plan Architecture (PDF)</span>
          </h2>
          <ul className="space-y-3 text-xs sm:text-sm text-slate-600">
            {program.highlights.map((h, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="w-2 h-2 rounded-full bg-slate-900 mt-2 shrink-0" />
                <span className="leading-relaxed">{h}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Free Sample Days Preview */}
      <section className="space-y-4">
        <div>
          <h2 className="text-2xl font-bold font-display text-slate-900">
            Free Preview: Sample Workouts & Diet Charts
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            Preview the structured daily warm-ups, sets, reps, form cues, and meal breakdown included in the complete plan.
          </p>
        </div>

        <InteractiveChart
          workoutDays={program.sampleDaysWorkout}
          dietDays={program.sampleDaysDiet}
          programTitle={program.title}
        />
      </section>

      {/* Pricing / Call to Action Bar */}
      <div className="bg-slate-900 text-white rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-slate-800">
        <div className="space-y-2">
          <div className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
            Instant Lifetime Access
          </div>
          <h3 className="text-2xl sm:text-3xl font-bold font-display">
            Get the Complete {program.title} PDF
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
            Download your high-resolution printable PDF plan immediately upon checkout. Compatible with smartphones, tablets, and desktop computers.
          </p>
        </div>

        <div className="text-center md:text-right shrink-0 space-y-3">
          <div className="flex items-baseline justify-center md:justify-end gap-2">
            <span className="text-sm text-slate-400 line-through">₹{program.originalPrice}</span>
            <span className="text-4xl font-black font-display text-white">₹{program.price}</span>
          </div>

          {isPurchased ? (
            <button
              onClick={handleDownload}
              className="px-8 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-md w-full sm:w-auto"
            >
              <Download className="w-5 h-5" />
              <span>Download PDF</span>
            </button>
          ) : (
            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                onClick={() => setScannerProgram(program)}
                className="px-6 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <QrCode className="w-4 h-4" />
                <span>Scan QR to Pay – ₹{program.price}</span>
              </button>
              <button
                onClick={() => buyNow(program)}
                className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all border border-slate-700"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Regular Checkout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
