import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { trackContact, trackLead } from '../../utils/metaPixel';
import { Send, MessageSquare, CheckCircle2, ShieldCheck, Clock, Sparkles } from 'lucide-react';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const ContactPage: React.FC = () => {
  const { showToast } = useApp();
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    subject: 'Question about 90-Day Challenge',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    showToast('Your inquiry has been submitted to the FitLife coaching team!');
    trackContact({ method: 'web_form', subject: formData.subject });
    trackLead({ content_name: 'Contact Inquiry' });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
          We Are Here For You
        </div>
        <h1 className="text-3xl sm:text-4xl font-black font-display text-slate-900 tracking-tight">
          Contact FitLife Support & Coaches
        </h1>
        <p className="text-sm text-slate-600">
          Need help downloading your plan, choosing a program, or configuring your daily calorie targets? Submit an inquiry directly to our team.
        </p>
      </div>

      <MedicalDisclaimer variant="compact" />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Support Highlights Side */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 space-y-6">
            <h2 className="text-lg font-bold font-display text-white border-b border-slate-800 pb-3">
              Member Support Features
            </h2>

            <div className="space-y-5 text-xs sm:text-sm">
              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-slate-400 text-xs">Automated PDF Vault</div>
                  <div className="font-bold text-white mt-0.5">Instant Digital Delivery</div>
                  <div className="text-[11px] text-slate-400">Lifetime access to all purchased workout & diet plans</div>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-slate-400 text-xs">Support Turnaround</div>
                  <div className="font-bold text-white mt-0.5">Priority Coaching Inquiries</div>
                  <div className="text-[11px] text-slate-400">In-app notifications and dedicated member assistance</div>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-slate-400 text-xs">Diet & Plan Guidance</div>
                  <div className="font-bold text-white mt-0.5">Vegetarian & Non-Veg Advice</div>
                  <div className="text-[11px] text-slate-400">Nutritional adjustments for fat loss and muscle building</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Form Side */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs">
          {submitted ? (
            <div className="py-12 text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">
                Message Received!
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 max-w-sm mx-auto">
                Thank you, {formData.name}. Your inquiry has been routed to our coaching staff.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="text-xs font-bold text-emerald-700 hover:underline"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              <h2 className="text-lg font-bold font-display text-slate-900 border-b border-slate-100 pb-3">
                Send Us an Inquiry
              </h2>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Your Name"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden text-xs sm:text-sm"
                >
                  <option>Question about 90-Day Challenge</option>
                  <option>Payment / PDF Download Help</option>
                  <option>Diet Chart Customization (Vegetarian / Vegan)</option>
                  <option>Joint / Posture Movement Inquiries</option>
                  <option>Other Feedback</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Your Message *</label>
                <textarea
                  required
                  rows={4}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell us about your fitness background, goal, or any questions..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm active:scale-98"
              >
                <Send className="w-4 h-4" />
                <span>Submit Inquiry</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
