import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PROGRAMS } from '../../data/programsData';
import { Program } from '../../types';
import { ShoppingBag, FileText, Download, CheckCircle2, ShieldCheck, Sparkles, Filter, QrCode } from 'lucide-react';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const ShopPage: React.FC = () => {
  const { addToCart, buyNow, setPreviewProgram, isProgramPurchased, setCurrentPage, setScannerProgram } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredPrograms = selectedCategory === 'all'
    ? PROGRAMS
    : PROGRAMS.filter((p) => {
        if (selectedCategory === 'fat-loss') return p.category === 'fat-loss';
        if (selectedCategory === 'muscle-gain') return p.category === 'muscle-gain';
        if (selectedCategory === 'posture') return p.category === 'posture';
        if (selectedCategory === 'mobility') return p.category === 'mobility' || p.category === 'general-wellness';
        return true;
      });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-10">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
          WooCommerce Digital Store
        </div>
        <h1 className="text-3xl sm:text-5xl font-black font-display text-slate-900 tracking-tight">
          Downloadable Diet & Exercise Plans
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          Structured 30 to 90-day workout splits, day-by-day vegetarian & non-vegetarian meal charts, posture drills, and printable PDF blueprints.
        </p>
      </div>

      {/* Safety Notice */}
      <MedicalDisclaimer variant="compact" />

      {/* Filter Tabs */}
      <div className="flex items-center justify-center gap-1.5 p-1.5 bg-slate-100 rounded-xl max-w-xl mx-auto overflow-x-auto">
        {[
          { id: 'all', label: 'All Plans' },
          { id: 'fat-loss', label: 'Fat Loss' },
          { id: 'muscle-gain', label: 'Muscle Gain' },
          { id: 'posture', label: 'Posture Correction' },
          { id: 'mobility', label: 'Mobility & Joints' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSelectedCategory(tab.id)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
              selectedCategory === tab.id
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Product Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredPrograms.map((program) => {
          const isPurchased = isProgramPurchased(program.id);
          return (
            <div
              key={program.id}
              className="bg-white rounded-2xl border border-slate-200/90 hover:border-slate-300 p-6 flex flex-col justify-between shadow-xs hover:shadow-md transition-all group"
            >
              <div>
                {/* Duration & Badge */}
                <div className="flex items-center justify-between text-xs mb-3">
                  <span className="font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md">
                    {program.duration}
                  </span>
                  {program.badge && (
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      {program.badge}
                    </span>
                  )}
                </div>

                <h3 className="text-xl font-bold font-display text-slate-900 group-hover:text-emerald-700 transition-colors">
                  {program.title}
                </h3>
                <p className="text-xs font-semibold text-slate-500 mt-1">
                  {program.tagline}
                </p>
                <p className="text-xs text-slate-600 mt-2.5 leading-relaxed line-clamp-3">
                  {program.shortDesc}
                </p>

                {/* Highlights */}
                <div className="mt-4 pt-4 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                  {program.highlights.slice(0, 3).map((h, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span className="line-clamp-1">{h}</span>
                    </div>
                  ))}
                </div>

                {program.category === 'general-wellness' && (
                  <div className="mt-3 text-[11px] text-amber-800 bg-amber-50 p-2 rounded-lg border border-amber-200/60 leading-tight">
                    *General wellness information, not medical treatment.
                  </div>
                )}
              </div>

              {/* Price & Action Area */}
              <div className="mt-6 pt-4 border-t border-slate-100 space-y-3">
                <div className="flex items-baseline justify-between">
                  <div>
                    <span className="text-xs text-slate-400 line-through mr-1.5">
                      ₹{program.originalPrice}
                    </span>
                    <span className="text-2xl font-black font-display text-slate-900">
                      ₹{program.price}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    Digital PDF Product
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setPreviewProgram(program)}
                    className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-colors text-center"
                  >
                    Free Preview
                  </button>

                  {isPurchased ? (
                    <button
                      onClick={() => setCurrentPage('download-plans')}
                      className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => setScannerProgram(program)}
                      className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                    >
                      <QrCode className="w-3.5 h-3.5" />
                      <span>Scan & Pay</span>
                    </button>
                  )}
                </div>

                {!isPurchased && (
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => buyNow(program)}
                      className="py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg text-center transition-colors"
                    >
                      Checkout – ₹{program.price}
                    </button>
                    <button
                      onClick={() => addToCart(program)}
                      className="py-2 border border-slate-200 hover:border-slate-300 text-slate-700 text-xs font-semibold rounded-lg flex items-center justify-center gap-1 transition-colors"
                    >
                      <ShoppingBag className="w-3 h-3" />
                      <span>Add to Cart</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* WooCommerce Guarantee Notice */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-sm sm:text-base text-slate-900">
              Automated Protected Download System
            </h4>
            <p className="text-xs sm:text-sm text-slate-600">
              Downloads unlock instantly upon confirmed payment. Retain lifetime re-download access in your My Account dashboard.
            </p>
          </div>
        </div>

        <button
          onClick={() => setCurrentPage('download-plans')}
          className="px-5 py-2.5 bg-white border border-slate-300 text-slate-800 hover:bg-slate-100 text-xs font-bold rounded-xl whitespace-nowrap transition-colors"
        >
          Check My Downloads
        </button>
      </div>
    </div>
  );
};
