import React from 'react';
import { useApp } from '../../context/AppContext';
import { FitLifeLogo } from '../common/FitLifeLogo';
import { ShieldCheck, Target, Heart, Award, ArrowRight, Dumbbell, Compass, Users } from 'lucide-react';
import { MedicalDisclaimer } from '../common/MedicalDisclaimer';

export const AboutPage: React.FC = () => {
  const { setCurrentPage } = useApp();

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
      {/* Hero */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="flex justify-center mb-2">
          <FitLifeLogo size="lg" />
        </div>
        <div className="text-xs font-bold text-emerald-600 uppercase tracking-widest">
          About FitLife Health & Wellness Community
        </div>
        <h1 className="text-3xl sm:text-5xl font-black font-display text-slate-900 tracking-tight">
          Democratizing Evidence-Based Indian Fitness
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          We founded FitLife to dismantle the confusion of extreme starvation diets and overpriced personal training. Our mission is simple: provide structured, realistic 90-day blueprints that anyone in India can follow at home or in the gym for only ₹250.
        </p>
      </div>

      {/* Safety Notice */}
      <MedicalDisclaimer />

      {/* 4 Pillars of FitLife */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
            <Compass className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            Real Indian Food First
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            You do not need to abandon roti, dal, or paneer to get lean. We engineer calorie-conscious, protein-optimized meal frameworks featuring everyday Indian ingredients.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
            <Target className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            Progressive 3-Phase Structure
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Random workouts give random results. Our 90-day curriculum uses progressive overload, planned deloads, and metabolic acceleration so you never plateau.
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold">
            <Award className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            Postural Longevity
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            A lean body in chronic pain is incomplete. Every FitLife workout incorporates spine decompressions, scapular glides, and hip mobility flows for modern desk workers.
          </p>
        </div>
      </div>

      {/* Community Numbers */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 border border-slate-800 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
        <div className="space-y-1">
          <div className="text-3xl sm:text-4xl font-black font-display text-emerald-400 tabular-nums">
            18,500+
          </div>
          <div className="text-xs text-slate-400">Plans Downloaded</div>
        </div>
        <div className="space-y-1">
          <div className="text-3xl sm:text-4xl font-black font-display text-white tabular-nums">
            94.2%
          </div>
          <div className="text-xs text-slate-400">Completion Rate</div>
        </div>
        <div className="space-y-1">
          <div className="text-3xl sm:text-4xl font-black font-display text-teal-400 tabular-nums">
            ₹250
          </div>
          <div className="text-xs text-slate-400">Fixed Transparent Price</div>
        </div>
        <div className="space-y-1">
          <div className="text-3xl sm:text-4xl font-black font-display text-amber-400 tabular-nums">
            4.9 / 5
          </div>
          <div className="text-xs text-slate-400">Average Member Rating</div>
        </div>
      </div>

      {/* CTA */}
      <div className="text-center pt-4">
        <button
          onClick={() => setCurrentPage('shop')}
          className="px-8 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl inline-flex items-center gap-2 transition-all shadow-sm"
        >
          <span>Explore All 5 Programs – ₹250</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
