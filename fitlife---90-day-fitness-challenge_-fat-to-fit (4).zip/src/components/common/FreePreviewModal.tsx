import React, { useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Check, ShoppingBag, Download, ArrowRight, ShieldCheck, Dumbbell, Sparkles, QrCode } from 'lucide-react';
import { InteractiveChart } from './InteractiveChart';
import { MedicalDisclaimer } from './MedicalDisclaimer';
import { generatePlanPDF } from '../../utils/pdfGenerator';
import { trackCustomEvent } from '../../utils/metaPixel';

export const FreePreviewModal: React.FC = () => {
  const { previewProgram, setPreviewProgram, buyNow, isProgramPurchased, user, showToast, setScannerProgram } = useApp();

  useEffect(() => {
    if (previewProgram) {
      trackCustomEvent('ViewFreePreview', {
        program_id: previewProgram.id,
        program_title: previewProgram.title
      });
    }
  }, [previewProgram?.id]);

  if (!previewProgram) return null;

  const isPurchased = isProgramPurchased(previewProgram.id);

  const handleDownload = () => {
    try {
      generatePlanPDF(previewProgram, user.name);
      showToast(`Downloading official "${previewProgram.title}" PDF...`);
    } catch (e) {
      console.error(e);
      showToast('Error generating PDF. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full my-auto shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Top Bar */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <span className="bg-emerald-500/20 text-emerald-400 text-xs font-bold px-2.5 py-1 rounded-md uppercase tracking-wider">
              Free Sample Preview
            </span>
            <span className="text-slate-400 text-xs hidden sm:inline">· 3 Sample Days Included</span>
          </div>

          <button
            onClick={() => setPreviewProgram(null)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-5 sm:p-7 space-y-6">
          {/* Header Info */}
          <div>
            <div className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">
              {previewProgram.duration} · {previewProgram.level}
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-display text-slate-900 mt-1">
              {previewProgram.title}
            </h2>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              {previewProgram.shortDesc}
            </p>
          </div>

          {/* Pricing & Purchase Banner */}
          <div className="bg-linear-to-r from-emerald-900 to-slate-900 text-white rounded-xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                <span>Complete Diet + Exercise Plan PDF</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black font-display text-white">
                  ₹{previewProgram.price}
                </span>
                <span className="text-sm text-slate-400 line-through">
                  ₹{previewProgram.originalPrice}
                </span>
                <span className="text-xs font-semibold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded">
                  Instant Lifetime Access
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Unlock full 90-day day-by-day charts, complete Indian vegetarian & non-veg meal plans, printable PDF & tracker.
              </p>
            </div>

            <div className="shrink-0 flex flex-col sm:flex-row gap-2">
              {isPurchased ? (
                <button
                  onClick={handleDownload}
                  className="w-full sm:w-auto px-6 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-md"
                >
                  <Download className="w-5 h-5" />
                  <span>Download Complete PDF</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={() => {
                      const prog = previewProgram;
                      setPreviewProgram(null);
                      setScannerProgram(prog);
                    }}
                    className="w-full sm:w-auto px-6 py-3 bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black rounded-xl flex items-center justify-center gap-2 transition-all shadow-md"
                  >
                    <QrCode className="w-5 h-5 text-slate-950" />
                    <span>Scan & Pay (₹{previewProgram.price})</span>
                  </button>

                  <button
                    onClick={() => {
                      buyNow(previewProgram);
                      setPreviewProgram(null);
                    }}
                    className="w-full sm:w-auto px-5 py-3 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-all border border-slate-700"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Regular Checkout</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Program Overview & Key Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="border border-slate-200 rounded-xl p-5">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Key Program Benefits</span>
              </h3>
              <ul className="space-y-2.5 text-xs sm:text-sm text-slate-600">
                {previewProgram.benefits.map((b, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0" />
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="border border-slate-200 rounded-xl p-5">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-2">
                <Dumbbell className="w-4 h-4 text-emerald-600" />
                <span>What Is Included in Full Plan</span>
              </h3>
              <ul className="space-y-2.5 text-xs sm:text-sm text-slate-600">
                {previewProgram.highlights.map((h, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-900 mt-2 shrink-0" />
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Interactive Chart for Free Sample Days */}
          <div>
            <div className="mb-2">
              <h3 className="text-base font-bold text-slate-900">
                Interactive Sample Days (Days 1–3)
              </h3>
              <p className="text-xs text-slate-500">
                Explore the structured workouts, warm-ups, sets/reps, meal variations and hydration reminder.
              </p>
            </div>

            <InteractiveChart
              workoutDays={previewProgram.sampleDaysWorkout}
              dietDays={previewProgram.sampleDaysDiet}
              programTitle={previewProgram.title}
            />
          </div>

          {/* Safety Disclaimer */}
          <MedicalDisclaimer variant="compact" />
        </div>

        {/* Modal Bottom CTA Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Secure 256-Bit SSL Checkout · Instant UPI / Cards</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setPreviewProgram(null)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
            >
              Close Preview
            </button>
            {isPurchased ? (
              <button
                onClick={handleDownload}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download PDF</span>
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const prog = previewProgram;
                    setPreviewProgram(null);
                    setScannerProgram(prog);
                  }}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <QrCode className="w-4 h-4" />
                  <span>Scan QR & Pay</span>
                </button>
                <button
                  onClick={() => {
                    buyNow(previewProgram);
                    setPreviewProgram(null);
                  }}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <span>Checkout (₹{previewProgram.price})</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
