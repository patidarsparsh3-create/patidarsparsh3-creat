import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { trackCustomEvent, trackLead } from '../../utils/metaPixel';
import { X, Calculator, ArrowRight, Activity, Flame, Droplets } from 'lucide-react';

export const BMICalculatorModal: React.FC = () => {
  const { isBmiModalOpen, setIsBmiModalOpen, setCurrentPage } = useApp();
  
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [age, setAge] = useState<number>(28);
  const [heightCm, setHeightCm] = useState<number>(172);
  const [weightKg, setWeightKg] = useState<number>(78);
  const [activity, setActivity] = useState<'sedentary' | 'light' | 'moderate' | 'active'>('moderate');
  const [goal, setGoal] = useState<'fat-loss' | 'muscle-gain' | 'maintenance'>('fat-loss');

  // Fire Meta Pixel event when BMI calculator is used
  useEffect(() => {
    if (isBmiModalOpen) {
      trackCustomEvent('OpenBMICalculator');
    }
  }, [isBmiModalOpen]);

  if (!isBmiModalOpen) return null;

  // Calculate BMI
  const heightM = heightCm / 100;
  const bmi = parseFloat((weightKg / (heightM * heightM)).toFixed(1));

  let bmiCategory = 'Normal';
  let bmiColor = 'text-emerald-600';
  if (bmi < 18.5) {
    bmiCategory = 'Underweight';
    bmiColor = 'text-amber-500';
  } else if (bmi >= 25 && bmi < 29.9) {
    bmiCategory = 'Overweight';
    bmiColor = 'text-orange-500';
  } else if (bmi >= 30) {
    bmiCategory = 'Obese';
    bmiColor = 'text-red-500';
  }

  // Calculate BMR (Mifflin-St Jeor)
  const bmr = gender === 'male'
    ? 10 * weightKg + 6.25 * heightCm - 5 * age + 5
    : 10 * weightKg + 6.25 * heightCm - 5 * age - 161;

  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725
  };

  const tdee = Math.round(bmr * activityMultipliers[activity]);

  let targetCalories = tdee;
  if (goal === 'fat-loss') {
    targetCalories = Math.round(tdee - 500); // 500 kcal deficit
  } else if (goal === 'muscle-gain') {
    targetCalories = Math.round(tdee + 300); // 300 kcal surplus
  }

  // Target Protein: 1.8g to 2.2g per kg
  const targetProteinGrams = Math.round(weightKg * 1.8);
  const targetWaterLiters = (weightKg * 0.045).toFixed(1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white rounded-t-2xl">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg font-display text-white">
                Fitness & Calorie Calculator
              </h3>
              <p className="text-xs text-slate-300">
                Calculate your custom 90-day daily calorie & macro targets
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsBmiModalOpen(false)}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-5">
          {/* Gender & Age */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                Gender
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setGender('male')}
                  className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                    gender === 'male'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200'
                  }`}
                >
                  Male
                </button>
                <button
                  type="button"
                  onClick={() => setGender('female')}
                  className={`py-2 text-xs font-semibold rounded-lg border transition-all ${
                    gender === 'female'
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200'
                  }`}
                >
                  Female
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                Age: {age} yrs
              </label>
              <input
                type="range"
                min="16"
                max="75"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </div>
          </div>

          {/* Height & Weight */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                Height (cm)
              </label>
              <input
                type="number"
                value={heightCm}
                onChange={(e) => setHeightCm(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                Current Weight (kg)
              </label>
              <input
                type="number"
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Goal */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
              Primary Goal
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'fat-loss', label: 'Fat Loss (-500 kcal)' },
                { id: 'muscle-gain', label: 'Muscle Gain (+300 kcal)' },
                { id: 'maintenance', label: 'Maintain & Mobility' }
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setGoal(item.id as any)}
                  className={`py-2 px-2 text-xs font-semibold rounded-lg border text-center transition-all ${
                    goal === item.id
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Activity Level */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
              Current Daily Activity
            </label>
            <select
              value={activity}
              onChange={(e) => setActivity(e.target.value as any)}
              className="w-full px-3 py-2 text-xs md:text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            >
              <option value="sedentary">Sedentary (Desk job, little to no exercise)</option>
              <option value="light">Lightly Active (1–3 days light exercise/week)</option>
              <option value="moderate">Moderately Active (3–5 days moderate workouts/week)</option>
              <option value="active">Very Active (6–7 days intense training)</option>
            </select>
          </div>

          {/* Results Card */}
          <div className="bg-slate-900 text-white rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <div className="text-xs text-slate-400 uppercase font-semibold">Your BMI</div>
                <div className="text-2xl font-bold font-display flex items-baseline gap-2">
                  <span>{bmi}</span>
                  <span className={`text-xs font-semibold ${bmiColor}`}>
                    ({bmiCategory})
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400 uppercase font-semibold">Daily Calorie Target</div>
                <div className="text-2xl font-bold font-display text-emerald-400">
                  {targetCalories} <span className="text-xs text-slate-300">kcal/day</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="bg-slate-800/80 p-2.5 rounded-lg">
                <div className="text-slate-400 text-[10px] uppercase font-bold">Protein Target</div>
                <div className="text-sm font-bold text-white mt-0.5">{targetProteinGrams} g/day</div>
              </div>
              <div className="bg-slate-800/80 p-2.5 rounded-lg">
                <div className="text-slate-400 text-[10px] uppercase font-bold">Maintenance (TDEE)</div>
                <div className="text-sm font-bold text-white mt-0.5">{tdee} kcal</div>
              </div>
              <div className="bg-slate-800/80 p-2.5 rounded-lg">
                <div className="text-slate-400 text-[10px] uppercase font-bold">Hydration</div>
                <div className="text-sm font-bold text-sky-400 mt-0.5">{targetWaterLiters} Liters</div>
              </div>
            </div>
          </div>

          {/* CTA to get 90-Day Plan */}
          <div className="pt-1">
            <button
              onClick={() => {
                trackLead({ content_name: 'BMI Calculator Lead', value: 250, currency: 'INR' });
                setIsBmiModalOpen(false);
                setCurrentPage('shop');
              }}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-sm"
            >
              <span>Get Customized 90-Day Plan PDF (₹250)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
