import React from 'react';
import { AlertCircle } from 'lucide-react';

interface MedicalDisclaimerProps {
  variant?: 'banner' | 'card' | 'compact';
  className?: string;
}

export const MedicalDisclaimer: React.FC<MedicalDisclaimerProps> = ({
  variant = 'card',
  className = '',
}) => {
  if (variant === 'compact') {
    return (
      <div className={`flex items-center gap-2 text-xs text-amber-900 bg-amber-50/90 border border-amber-200/80 rounded-lg px-3 py-2 ${className}`}>
        <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
        <p className="font-medium">
          <strong>Note:</strong> Do exercise according to your pain, don't over stretch.
        </p>
      </div>
    );
  }

  if (variant === 'banner') {
    return (
      <aside aria-label="Exercise Note" className={`bg-amber-50/90 border-y border-amber-200/80 py-2.5 px-4 ${className}`}>
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 text-xs md:text-sm text-amber-900 text-center font-medium">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          <p>
            <strong>Note:</strong> Do exercise according to your pain, don't over stretch.
          </p>
        </div>
      </aside>
    );
  }

  return (
    <div className={`bg-amber-50/90 border border-amber-200/80 rounded-xl px-4 py-3 shadow-2xs flex items-center gap-3 ${className}`}>
      <div className="w-7 h-7 rounded-lg bg-amber-100 flex items-center justify-center shrink-0 text-amber-700">
        <AlertCircle className="w-4 h-4" />
      </div>
      <p className="text-xs sm:text-sm text-amber-900 font-medium">
        <strong>Note:</strong> Do exercise according to your pain, don't over stretch.
      </p>
    </div>
  );
};
