import React, { useState } from 'react';
import { DayWorkout, DayMealPlan } from '../../types';
import { Dumbbell, Utensils, Droplets, Clock, Flame, ChevronRight, CheckCircle2, Info, Sparkles, Activity } from 'lucide-react';

interface InteractiveChartProps {
  workoutDays: DayWorkout[];
  dietDays: DayMealPlan[];
  programTitle: string;
  className?: string;
  defaultTab?: 'workout' | 'diet';
}

export const InteractiveChart: React.FC<InteractiveChartProps> = ({
  workoutDays,
  dietDays,
  programTitle,
  className = '',
  defaultTab = 'workout'
}) => {
  const [activeTab, setActiveTab] = useState<'workout' | 'diet'>(defaultTab);
  const [selectedDayIdx, setSelectedDayIdx] = useState<number>(0);
  const [dietPreference, setDietPreference] = useState<'veg' | 'nonVeg'>('veg');
  const [experienceLevel, setExperienceLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');

  const currentWorkout = workoutDays[selectedDayIdx] || workoutDays[0];
  const currentDiet = dietDays[selectedDayIdx] || dietDays[0];

  const levelNotes = {
    beginner: 'Take 75-90s rest between sets. Focus 100% on form mastery and full range of motion before increasing weight.',
    intermediate: 'Maintain 60s rest intervals. Aim for progressive overload by increasing weight or adding 1-2 reps each week.',
    advanced: 'Apply 3-second eccentric (lowering) tempo on all lifts with 45s rest to maximize metabolic stress and muscle tension.'
  };

  return (
    <div className={`bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden ${className}`}>
      {/* Top Controller Bar */}
      <div className="bg-slate-900 text-white p-5 md:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-1">
            <Activity className="w-4 h-4" />
            <span>Interactive Chart · {programTitle}</span>
          </div>
          <h3 className="text-xl md:text-2xl font-bold font-display text-white">
            Daily Workout & Nutrition Blueprint
          </h3>
          <p className="text-xs md:text-sm text-slate-300 mt-0.5">
            Structured day-by-day charts with warm-ups, sets, reps, meals & hydration guidelines
          </p>
        </div>

        {/* Tab switchers: Workout vs Diet */}
        <div className="flex items-center bg-slate-800 p-1.5 rounded-xl border border-slate-700/60 self-start md:self-auto shrink-0">
          <button
            onClick={() => setActiveTab('workout')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs md:text-sm font-semibold transition-all ${
              activeTab === 'workout'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Dumbbell className="w-4 h-4" />
            <span>Workout Chart</span>
          </button>
          <button
            onClick={() => setActiveTab('diet')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs md:text-sm font-semibold transition-all ${
              activeTab === 'diet'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <Utensils className="w-4 h-4" />
            <span>Diet & Meals</span>
          </button>
        </div>
      </div>

      {/* Sub-bar: Day Selection & Preferences */}
      <div className="bg-slate-50 border-b border-slate-200 px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Day Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1">
          <span className="font-semibold text-slate-500 uppercase tracking-wider text-[11px] mr-1 hidden sm:inline">
            Day:
          </span>
          {workoutDays.map((day, idx) => (
            <button
              key={day.dayNumber}
              onClick={() => setSelectedDayIdx(idx)}
              className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                selectedDayIdx === idx
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300'
              }`}
            >
              Day {day.dayNumber} {day.isRestDay ? '(Rest)' : ''}
            </button>
          ))}
        </div>

        {/* Dynamic controls depending on tab */}
        {activeTab === 'workout' ? (
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium hidden sm:inline">Level:</span>
            <div className="flex bg-slate-200/80 p-0.5 rounded-md">
              {(['beginner', 'intermediate', 'advanced'] as const).map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setExperienceLevel(lvl)}
                  className={`px-2.5 py-1 rounded text-[11px] font-semibold capitalize transition-colors ${
                    experienceLevel === lvl ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium hidden sm:inline">Diet Option:</span>
            <div className="flex bg-slate-200/80 p-0.5 rounded-md">
              <button
                onClick={() => setDietPreference('veg')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                  dietPreference === 'veg' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                100% Vegetarian
              </button>
              <button
                onClick={() => setDietPreference('nonVeg')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                  dietPreference === 'nonVeg' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                Non-Vegetarian / High-Protein
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Main Tab Content */}
      <div className="p-5 md:p-7">
        {activeTab === 'workout' ? (
          <div className="space-y-6">
            {/* Header info card */}
            <div className="bg-emerald-50/60 border border-emerald-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-emerald-800 uppercase tracking-wide">
                  {currentWorkout.dayTitle}
                </div>
                <div className="text-sm font-semibold text-slate-800 mt-0.5">
                  Focus: {currentWorkout.focus}
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 bg-emerald-100/70 px-3 py-1.5 rounded-lg shrink-0">
                <Flame className="w-3.5 h-3.5" />
                <span>Cardio Step Target: {currentWorkout.cardioStepGoal}</span>
              </div>
            </div>

            {/* Level progression cue */}
            <div className="flex items-start gap-2.5 text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <p>
                <strong className="font-semibold text-slate-800 capitalize">{experienceLevel} Option:</strong>{' '}
                {levelNotes[experienceLevel]}
              </p>
            </div>

            {/* Warm-Up section */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <div className="bg-slate-100/70 px-4 py-2.5 flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
                <Clock className="w-3.5 h-3.5 text-emerald-600" />
                <span>Warm-Up Protocol (5–7 Minutes)</span>
              </div>
              <div className="p-4 text-xs md:text-sm text-slate-700 bg-white">
                {currentWorkout.warmUp}
              </div>
            </div>

            {/* Exercise Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <div className="bg-slate-900 text-white px-4 py-3 text-xs font-bold uppercase tracking-wider flex items-center justify-between">
                <span>Exercises & Working Sets</span>
                <span className="text-slate-400 font-normal">Rest: 45–90s between sets</span>
              </div>

              <div className="divide-y divide-slate-200">
                {currentWorkout.exercises.map((ex, idx) => (
                  <div key={idx} className="p-4 hover:bg-slate-50/70 transition-colors">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <h4 className="text-sm md:text-base font-bold text-slate-900">
                            {ex.name}
                          </h4>
                          <span className="text-[11px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                            {ex.targetMuscle}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 pl-7">
                          <strong className="text-slate-700">Form Cue:</strong> {ex.formCue}
                        </p>
                      </div>

                      <div className="flex items-center gap-4 text-xs font-semibold pl-7 md:pl-0 shrink-0">
                        <div className="bg-emerald-50 text-emerald-900 border border-emerald-200 px-2.5 py-1 rounded">
                          {ex.sets}
                        </div>
                        <div className="bg-slate-100 text-slate-800 px-2.5 py-1 rounded">
                          {ex.repsOrTime}
                        </div>
                        <div className="text-slate-500 text-[11px]">
                          Rest: {ex.rest}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Cool-Down & Mobility */}
            <div className="border border-slate-200 rounded-xl overflow-hidden">
              <div className="bg-slate-100/70 px-4 py-2.5 flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Cool-Down & Post-Workout Stretching</span>
              </div>
              <div className="p-4 text-xs md:text-sm text-slate-700 bg-white">
                {currentWorkout.coolDown}
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Diet Header Card */}
            <div className="bg-amber-50/60 border border-amber-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-amber-800 uppercase tracking-wide">
                  Daily Nutrition Blueprint · Day {currentDiet.dayNumber}
                </div>
                <div className="text-sm font-semibold text-slate-800 mt-0.5">
                  Calorie Target: {currentDiet.calorieTarget}
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold text-sky-800 bg-sky-100/80 px-3 py-1.5 rounded-lg shrink-0">
                <Droplets className="w-3.5 h-3.5 text-sky-600" />
                <span>Hydration: {currentDiet.hydrationGoal}</span>
              </div>
            </div>

            {/* Meal Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Breakfast */}
              <div className="border border-slate-200 rounded-xl p-4 hover:border-emerald-300 transition-colors bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    01. Breakfast (8:00 AM)
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {currentDiet.breakfast.calories}
                  </span>
                </div>
                <p className="text-xs md:text-sm text-slate-800 leading-relaxed font-medium">
                  {dietPreference === 'veg' ? currentDiet.breakfast.veg : currentDiet.breakfast.nonVeg}
                </p>
              </div>

              {/* Lunch */}
              <div className="border border-slate-200 rounded-xl p-4 hover:border-emerald-300 transition-colors bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    02. Lunch (1:00 PM)
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {currentDiet.lunch.calories}
                  </span>
                </div>
                <p className="text-xs md:text-sm text-slate-800 leading-relaxed font-medium">
                  {dietPreference === 'veg' ? currentDiet.lunch.veg : currentDiet.lunch.nonVeg}
                </p>
              </div>

              {/* Snacks */}
              <div className="border border-slate-200 rounded-xl p-4 hover:border-emerald-300 transition-colors bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    03. Evening Snack (4:30 PM)
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {currentDiet.snacks.calories}
                  </span>
                </div>
                <p className="text-xs md:text-sm text-slate-800 leading-relaxed font-medium">
                  {dietPreference === 'veg' ? currentDiet.snacks.veg : currentDiet.snacks.nonVeg}
                </p>
              </div>

              {/* Dinner */}
              <div className="border border-slate-200 rounded-xl p-4 hover:border-emerald-300 transition-colors bg-white">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    04. Dinner (7:30 PM)
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {currentDiet.dinner.calories}
                  </span>
                </div>
                <p className="text-xs md:text-sm text-slate-800 leading-relaxed font-medium">
                  {dietPreference === 'veg' ? currentDiet.dinner.veg : currentDiet.dinner.nonVeg}
                </p>
              </div>
            </div>

            {/* Hydration & Nutrition Pro-Tip */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-700">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <strong className="font-semibold text-slate-900">Nutrition Strategy Tip:</strong>{' '}
                {currentDiet.keyNutritionTip}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
