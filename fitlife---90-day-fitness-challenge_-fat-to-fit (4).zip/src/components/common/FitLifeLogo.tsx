import React from 'react';

interface FitLifeLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
  inverted?: boolean;
}

export const FitLifeLogo: React.FC<FitLifeLogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true,
  inverted = false,
}) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12'
  };

  const titleSizes = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-3xl'
  };

  const subtitleSizes = {
    sm: 'text-[9px]',
    md: 'text-[10px]',
    lg: 'text-xs'
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Brand Icon SVG matching uploaded screenshot */}
      <div className={`relative ${iconSizes[size]} shrink-0 flex items-center justify-center`}>
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-sm"
        >
          <defs>
            <linearGradient id="fitlifeGrad" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#0D9488" />
              <stop offset="50%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#34D399" />
            </linearGradient>
            <linearGradient id="arrowGrad" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#059669" />
              <stop offset="100%" stopColor="#10B981" />
            </linearGradient>
          </defs>

          {/* Circular bottom swoosh */}
          <path
            d="M 28 64 C 36 78 64 80 74 65"
            stroke="url(#fitlifeGrad)"
            strokeWidth="5"
            strokeLinecap="round"
          />

          {/* Upward Growth Arrow swoosh */}
          <path
            d="M 32 60 C 42 62 60 52 75 30"
            stroke="url(#arrowGrad)"
            strokeWidth="6"
            strokeLinecap="round"
          />
          {/* Arrowhead */}
          <path
            d="M 68 25 L 79 28 L 76 39 Z"
            fill="#10B981"
          />

          {/* Left Organic Leaf */}
          <path
            d="M 40 48 C 30 45 28 35 34 28 C 42 32 44 42 40 48 Z"
            stroke="url(#fitlifeGrad)"
            strokeWidth="4"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M 34 38 C 36 36 38 36 39 37"
            stroke="url(#fitlifeGrad)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Right Upward Leaf */}
          <path
            d="M 52 42 C 48 30 52 20 62 20 C 66 30 60 38 52 42 Z"
            stroke="url(#fitlifeGrad)"
            strokeWidth="4"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M 54 32 C 55 28 57 26 59 25"
            stroke="url(#fitlifeGrad)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col leading-tight">
        <span
          className={`font-black tracking-tight font-display ${titleSizes[size]} ${
            inverted ? 'text-white' : 'text-[#0B192C]'
          }`}
        >
          FITLIFE
        </span>
        {showSubtitle && (
          <span
            className={`font-semibold tracking-wider uppercase ${subtitleSizes[size]} ${
              inverted ? 'text-emerald-300' : 'text-[#0F2847]/80'
            }`}
          >
            Health & Wellness Community
          </span>
        )}
      </div>
    </div>
  );
};
