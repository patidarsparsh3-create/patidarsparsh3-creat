import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Program } from '../../types';
import { generatePlanPDF } from '../../utils/pdfGenerator';
import confetti from 'canvas-confetti';
import { CheckCircle2, Download, ArrowRight, Sparkles, ShieldCheck, X, FileText, Check } from 'lucide-react';

interface ThankYouModalProps {
  program: Program | null;
  orderId?: string;
  onClose: () => void;
}

export const ThankYouModal: React.FC<ThankYouModalProps> = ({
  program,
  orderId = `FL-${Math.floor(100000 + Math.random() * 900000)}`,
  onClose
}) => {
  const { user, showToast, setCurrentPage } = useApp();
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [downloadTriggered, setDownloadTriggered] = useState<boolean>(false);

  useEffect(() => {
    if (!program) return;

    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 }
      });
      setTimeout(() => {
        confetti({
          particleCount: 60,
          angle: 60,
          spread: 55,
          origin: { x: 0 }
        });
        confetti({
          particleCount: 60,
          angle: 120,
          spread: 55,
          origin: { x: 1 }
        });
      }, 400);
    } catch (e) {
      console.error(e);
    }

    // Auto-progress bar leading to automatic download
    const timer = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return prev + 25;
      });
    }, 250);

    return () => clearInterval(timer);
  }, [program]);

  // When progress reaches 100%, trigger automatic download once
  useEffect(() => {
    if (downloadProgress === 100 && !downloadTriggered && program) {
      setDownloadTriggered(true);
      try {
        generatePlanPDF(program, user.name, orderId);
        showToast(`Downloaded "${program.title}" official PDF!`);
      } catch (err) {
        console.error(err);
      }
    }
  }, [downloadProgress, downloadTriggered, program, user.name, orderId, showToast]);

  if (!program) return null;

  const handleManualDownload = () => {
    try {
      generatePlanPDF(program, user.name, orderId);
      showToast(`Downloading "${program.title}" PDF...`);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full my-auto shadow-2xl border border-slate-200 overflow-hidden text-center flex flex-col relative animate-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Celebration Graphic */}
        <div className="bg-linear-to-b from-emerald-500 to-teal-600 text-white pt-10 pb-8 px-6 relative overflow-hidden">
          {/* Animated pulsing ring */}
          <div className="relative mx-auto w-20 h-20 mb-4 flex items-center justify-center">
            <span className="absolute inset-0 rounded-full bg-white/20 animate-ping" />
            <div className="w-20 h-20 rounded-full bg-white text-emerald-600 flex items-center justify-center shadow-lg relative z-10">
              <Check className="w-12 h-12 stroke-[3]" />
            </div>
          </div>

          <div className="space-y-1">
            <span className="inline-block bg-white/20 backdrop-blur-xs text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              Payment Confirmed · ₹250
            </span>
            <h2 className="text-2xl sm:text-3xl font-black font-display text-white">
              Thank You for Your Payment!
            </h2>
            <p className="text-xs sm:text-sm text-emerald-50 max-w-sm mx-auto">
              Your official FitLife Diet & Exercise Blueprint has been unlocked.
            </p>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Purchased Plan Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 text-left space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-500 uppercase tracking-wide">
                Purchased Plan
              </span>
              <span className="font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded">
                Order #{orderId}
              </span>
            </div>

            <div>
              <h3 className="font-bold text-base sm:text-lg text-slate-900 font-display">
                {program.title}
              </h3>
              <p className="text-xs text-slate-600 mt-0.5">
                {program.duration} · Complete Workout Split & Dual Diet Charts
              </p>
            </div>

            <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs text-slate-500">
              <span>Licensed to: <strong>{user.name}</strong></span>
              <span className="tabular-nums font-bold text-slate-900">₹{program.price} Paid</span>
            </div>
          </div>

          {/* Automatic Download Status Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
              <span className="flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>Generating High-Resolution PDF...</span>
              </span>
              <span className="text-emerald-700 font-bold">{downloadProgress}%</span>
            </div>

            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-emerald-500 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${downloadProgress}%` }}
              />
            </div>

            <p className="text-[11px] text-slate-400">
              {downloadTriggered
                ? 'Your browser has downloaded the PDF file.'
                : 'Your file is automatically downloading to your device...'}
            </p>
          </div>

          {/* Primary Action Button */}
          <div className="space-y-3 pt-2">
            <button
              onClick={handleManualDownload}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 transition-all shadow-md active:scale-98"
            >
              <Download className="w-5 h-5" />
              <span>Download Complete Plan PDF Now</span>
            </button>

            <button
              onClick={() => {
                onClose();
                setCurrentPage('download-plans');
              }}
              className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors"
            >
              View in Protected Downloads Vault →
            </button>
          </div>

          <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 pt-2 border-t border-slate-100">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Lifetime re-download access active in your My Account tab</span>
          </div>
        </div>
      </div>
    </div>
  );
};
