import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { Program } from '../../types';
import QRCode from 'qrcode';
import { trackInitiateCheckout, trackAddPaymentInfo } from '../../utils/metaPixel';
import { X, ShieldCheck, CheckCircle2, Smartphone, ArrowRight, Sparkles, RefreshCw, QrCode } from 'lucide-react';

interface PaymentScannerModalProps {
  program: Program | null;
  onClose: () => void;
  onPaymentSuccess: (program: Program, utr?: string) => void;
}

export const PaymentScannerModal: React.FC<PaymentScannerModalProps> = ({
  program,
  onClose,
  onPaymentSuccess
}) => {
  const { user } = useApp();
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [utrNumber, setUtrNumber] = useState<string>('');
  const [payerName, setPayerName] = useState<string>(user.name || 'Member');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  const upiId = 'fitlife.wellness@ybl'; // PhonePe handle matching the Pe QR code

  useEffect(() => {
    if (!program) return;

    // Fire Meta Pixel Checkout & Payment Info events
    trackInitiateCheckout({
      value: program.price,
      num_items: 1,
      content_ids: [program.id],
      currency: 'INR'
    });
    trackAddPaymentInfo({
      payment_type: 'PHONEPE_UPI_QR',
      value: program.price,
      currency: 'INR'
    });

    // Generate real UPI payment string for 250 INR
    const upiPayload = `upi://pay?pa=${upiId}&pn=FitLife%20Health&am=${program.price}&cu=INR&tn=FitLife_${program.slug}_Plan`;

    // Render QR Code onto a canvas, then overlay the PhonePe "पे" central badge
    const canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 400;

    QRCode.toCanvas(
      canvas,
      upiPayload,
      {
        width: 400,
        margin: 2,
        errorCorrectionLevel: 'H',
        color: {
          dark: '#000000',
          light: '#ffffff'
        }
      },
      (err) => {
        if (err) {
          console.error(err);
          return;
        }

        const ctx = canvas.getContext('2d');
        if (ctx) {
          const centerX = canvas.width / 2;
          const centerY = canvas.height / 2;
          const radius = 38;

          // Draw white background ring
          ctx.beginPath();
          ctx.arc(centerX, centerY, radius + 4, 0, Math.PI * 2);
          ctx.fillStyle = '#ffffff';
          ctx.fill();

          // Draw PhonePe purple/black dark circle
          ctx.beginPath();
          ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
          ctx.fillStyle = '#1c1c1e';
          ctx.fill();

          // Draw white PhonePe 'पे' emblem
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 44px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('पे', centerX, centerY + 2);
        }

        setQrDataUrl(canvas.toDataURL('image/png'));
      }
    );
  }, [program]);

  if (!program) return null;

  const handleConfirmPayment = () => {
    setIsVerifying(true);
    // Simulate real verification check
    setTimeout(() => {
      setIsVerifying(false);
      onPaymentSuccess(program, utrNumber || `UPI${Math.floor(100000000000 + Math.random() * 900000000000)}`);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full my-auto shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base font-display text-white">
                UPI Payment Scanner
              </h3>
              <p className="text-xs text-slate-300">
                Scan with PhonePe, GPay, Paytm or any UPI App
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-7 space-y-6">
          {/* Plan Summary Strip */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider">
                Instant PDF Unlock Plan
              </span>
              <h4 className="font-bold text-sm sm:text-base text-slate-900 line-clamp-1">
                {program.title}
              </h4>
              <p className="text-xs text-slate-600">
                Full 90-Day Diet & Workout Blueprint
              </p>
            </div>

            <div className="text-right shrink-0">
              <span className="text-[10px] text-slate-400 block line-through">
                ₹{program.originalPrice}
              </span>
              <span className="text-2xl font-black font-display text-slate-900 tabular-nums">
                ₹{program.price}
              </span>
            </div>
          </div>

          {/* QR Code Scanner Card */}
          <div className="flex flex-col items-center text-center space-y-3">
            {/* The QR Scanner Frame */}
            <div className="relative p-3 bg-white border-2 border-slate-900 rounded-2xl shadow-md inline-block">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="FitLife PhonePe UPI QR Scanner"
                  className="w-56 h-56 sm:w-64 sm:h-64 object-contain rounded-lg"
                />
              ) : (
                <div className="w-56 h-56 sm:w-64 sm:h-64 flex items-center justify-center bg-slate-100 rounded-lg">
                  <RefreshCw className="w-8 h-8 text-slate-400 animate-spin" />
                </div>
              )}

              {/* Corner target guides */}
              <div className="absolute top-1 left-1 w-4 h-4 border-t-2 border-l-2 border-emerald-600" />
              <div className="absolute top-1 right-1 w-4 h-4 border-t-2 border-r-2 border-emerald-600" />
              <div className="absolute bottom-1 left-1 w-4 h-4 border-b-2 border-l-2 border-emerald-600" />
              <div className="absolute bottom-1 right-1 w-4 h-4 border-b-2 border-r-2 border-emerald-600" />
            </div>

            {/* Supported App Logos pill */}
            <div className="flex items-center justify-center gap-2 pt-1 text-[11px] text-slate-500 font-medium">
              <span className="bg-slate-100 px-2 py-0.5 rounded">PhonePe</span>
              <span>·</span>
              <span className="bg-slate-100 px-2 py-0.5 rounded">Google Pay</span>
              <span>·</span>
              <span className="bg-slate-100 px-2 py-0.5 rounded">Paytm</span>
              <span>·</span>
              <span className="bg-slate-100 px-2 py-0.5 rounded">BHIM UPI</span>
            </div>
          </div>

          {/* Payment Confirmation Inputs */}
          <div className="space-y-3 pt-2 border-t border-slate-100 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Your Name (for PDF License)
                </label>
                <input
                  type="text"
                  value={payerName}
                  onChange={(e) => setPayerName(e.target.value)}
                  placeholder="Your Name"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  12-Digit UTR / UPI Ref No. (Optional)
                </label>
                <input
                  type="text"
                  value={utrNumber}
                  onChange={(e) => setUtrNumber(e.target.value)}
                  placeholder="e.g. 428190348219"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden tabular-nums font-mono"
                />
              </div>
            </div>

            {/* Action CTA */}
            <button
              onClick={handleConfirmPayment}
              disabled={isVerifying}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 transition-all shadow-md active:scale-98 disabled:opacity-75"
            >
              {isVerifying ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Verifying Payment...</span>
                </span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>I Have Paid ₹{program.price} – Unlock & Download PDF</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Instant Thank You animation and automated PDF download will trigger immediately</span>
          </div>
        </div>
      </div>
    </div>
  );
};
