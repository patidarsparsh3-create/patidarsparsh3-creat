import { jsPDF } from 'jspdf';
import { Program } from '../types';

export const generatePlanPDF = (
  program: Program,
  customerName = 'FitLife Member',
  orderId = `FL-${Math.floor(100000 + Math.random() * 900000)}`
): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  const contentWidth = pageWidth - margin * 2;

  // Colors
  const navy = [11, 25, 44]; // #0B192C
  const emerald = [5, 150, 105]; // #059669
  const darkSlate = [30, 41, 59];
  const muted = [100, 116, 139];
  const lightBg = [248, 250, 252];

  let y = margin;

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - margin - 12) {
      doc.addPage();
      y = margin;
      drawHeaderFooter();
    }
  };

  const drawHeaderFooter = () => {
    const totalPages = (doc as any).internal.getNumberOfPages();
    // Header banner
    doc.setFillColor(navy[0], navy[1], navy[2]);
    doc.rect(margin, margin, contentWidth, 8, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.text('FITLIFE HEALTH & WELLNESS COMMUNITY  |  OFFICIAL DIGITAL GUIDE', margin + 4, margin + 5.5);
    doc.text('PRICE: RS. 250 COMPLETE PLAN', pageWidth - margin - 4, margin + 5.5, { align: 'right' });

    // Footer
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(muted[0], muted[1], muted[2]);
    doc.text(`FitLife Plan License: ${customerName} · Order ${orderId}`, margin, pageHeight - margin + 5);
    doc.text(`Page ${totalPages}`, pageWidth - margin, pageHeight - margin + 5, { align: 'right' });
    y = margin + 14;
  };

  // --- PAGE 1: COVER & OVERVIEW ---
  drawHeaderFooter();

  // Hero Box
  doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
  doc.roundedRect(margin, y, contentWidth, 54, 3, 3, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin, y, contentWidth, 54, 3, 3, 'S');

  doc.setTextColor(emerald[0], emerald[1], emerald[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('OFFICIAL TRANSFORMATION BLUEPRINT · DIET & EXERCISE', margin + 6, y + 10);

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFontSize(18);
  doc.text(program.title, margin + 6, y + 20);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
  const splitTagline = doc.splitTextToSize(program.tagline + ' — ' + program.shortDesc, contentWidth - 12);
  doc.text(splitTagline, margin + 6, y + 28);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(muted[0], muted[1], muted[2]);
  doc.text(`DURATION: ${program.duration.toUpperCase()}   |   LEVEL: ${program.level.toUpperCase()}   |   ISSUED TO: ${customerName.toUpperCase()}`, margin + 6, y + 48);

  y += 62;

  // Member Guidance Note Box
  doc.setFillColor(254, 243, 199); // warm amber
  doc.setDrawColor(245, 158, 11);
  doc.roundedRect(margin, y, contentWidth, 14, 2, 2, 'FD');
  doc.setTextColor(146, 64, 14);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text("NOTE: DO EXERCISE ACCORDING TO YOUR PAIN, DON'T OVER STRETCH.", margin + 4, y + 9);

  y += 20;

  // Key Highlights
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('PROGRAM CORE PILLARS & BENEFITS', margin, y);
  y += 6;

  program.benefits.forEach((benefit) => {
    checkPageBreak(8);
    doc.setFillColor(emerald[0], emerald[1], emerald[2]);
    doc.circle(margin + 2, y - 1, 1.2, 'F');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    const splitBenefit = doc.splitTextToSize(benefit, contentWidth - 10);
    doc.text(splitBenefit, margin + 6, y);
    y += splitBenefit.length * 4.5;
  });

  y += 4;

  // Roadmap Breakdown
  checkPageBreak(35);
  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text('THE 90-DAY PROGRESSION TIMELINE', margin, y);
  y += 6;

  const phases = [
    { title: 'Phase 1: Days 1 to 30 — Metabolic Reset & Form Foundation', desc: 'Condition tendons, activate dormant core & glutes, establish 3.5L hydration habit and caloric deficit/surplus calibration.' },
    { title: 'Phase 2: Days 31 to 60 — Progressive Overload & Acceleration', desc: 'Increase mechanical tension, push cardio intensity, step volume to 10k/day, and refine meal timing.' },
    { title: 'Phase 3: Days 61 to 90 — Peak Definition & Habit Mastery', desc: 'Peak metabolic conditioning, locked posture alignment, maximum lean definition, and permanent lifestyle maintenance.' }
  ];

  phases.forEach((p) => {
    checkPageBreak(14);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(emerald[0], emerald[1], emerald[2]);
    doc.text(p.title, margin, y);
    y += 4.5;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(muted[0], muted[1], muted[2]);
    const splitP = doc.splitTextToSize(p.desc, contentWidth);
    doc.text(splitP, margin, y);
    y += splitP.length * 4 + 3;
  });

  // --- PAGE 2: DETAILED WORKOUT SCHEDULE ---
  doc.addPage();
  drawHeaderFooter();

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('STRUCTURED WORKOUT SCHEDULE & EXERCISE CHARTS', margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(muted[0], muted[1], muted[2]);
  doc.text('Execute each exercise with controlled eccentric tempo. Rest intervals must be timed precisely.', margin, y);
  y += 8;

  program.sampleDaysWorkout.forEach((day) => {
    checkPageBreak(35);

    // Day Header Bar
    doc.setFillColor(navy[0], navy[1], navy[2]);
    doc.roundedRect(margin, y, contentWidth, 7, 1.5, 1.5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(`${day.dayTitle}  ·  Focus: ${day.focus}`, margin + 3, y + 4.8);
    y += 10;

    // Warm-up & Cool-down
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(emerald[0], emerald[1], emerald[2]);
    doc.text(`WARM-UP: ${day.warmUp}`, margin + 2, y);
    y += 4.5;
    doc.setTextColor(darkSlate[0], darkSlate[1], darkSlate[2]);
    doc.text(`COOL-DOWN: ${day.coolDown}  |  STEPS: ${day.cardioStepGoal}`, margin + 2, y);
    y += 6;

    // Exercises
    day.exercises.forEach((ex, idx) => {
      checkPageBreak(12);
      doc.setFillColor(idx % 2 === 0 ? 250 : 255, idx % 2 === 0 ? 250 : 255, idx % 2 === 0 ? 250 : 255);
      doc.rect(margin, y - 3, contentWidth, 9, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(navy[0], navy[1], navy[2]);
      doc.text(`${idx + 1}. ${ex.name}`, margin + 2, y + 1);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(emerald[0], emerald[1], emerald[2]);
      doc.text(`${ex.sets}  x  ${ex.repsOrTime}  (Rest: ${ex.rest})`, margin + 85, y + 1);

      y += 5;
      doc.setFontSize(7.5);
      doc.setTextColor(muted[0], muted[1], muted[2]);
      doc.text(`Cue: ${ex.formCue} [Target: ${ex.targetMuscle}]`, margin + 6, y);
      y += 6;
    });

    y += 4;
  });

  // --- PAGE 3: COMPREHENSIVE DIET & MEAL CHARTS ---
  doc.addPage();
  drawHeaderFooter();

  doc.setTextColor(navy[0], navy[1], navy[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('NUTRITION BLUEPRINT: VEGETARIAN & NON-VEGETARIAN CHARTS', margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(muted[0], muted[1], muted[2]);
  doc.text('Calculated macro distribution: 40% Clean Carbs, 30% Lean Protein, 30% Healthy Fats. Hydration: 3.5L/day minimum.', margin, y);
  y += 8;

  program.sampleDaysDiet.forEach((diet) => {
    checkPageBreak(45);

    // Meal Day Header
    doc.setFillColor(emerald[0], emerald[1], emerald[2]);
    doc.roundedRect(margin, y, contentWidth, 7, 1.5, 1.5, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(`Day ${diet.dayNumber} Meal Blueprint  ·  Target: ${diet.calorieTarget}`, margin + 3, y + 4.8);
    y += 10;

    const mealSlots = [
      { name: 'BREAKFAST', data: diet.breakfast },
      { name: 'LUNCH', data: diet.lunch },
      { name: 'EVENING SNACK', data: diet.snacks },
      { name: 'DINNER', data: diet.dinner }
    ];

    mealSlots.forEach((slot) => {
      checkPageBreak(15);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(navy[0], navy[1], navy[2]);
      doc.text(`${slot.name} (${slot.data.calories}):`, margin + 2, y);
      y += 4;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(22, 101, 52); // green for veg
      const vegText = `[VEG]: ${slot.data.veg}`;
      const splitVeg = doc.splitTextToSize(vegText, contentWidth - 4);
      doc.text(splitVeg, margin + 4, y);
      y += splitVeg.length * 3.8;

      doc.setTextColor(153, 27, 27); // red for non-veg
      const nonVegText = `[NON-VEG]: ${slot.data.nonVeg}`;
      const splitNonVeg = doc.splitTextToSize(nonVegText, contentWidth - 4);
      doc.text(splitNonVeg, margin + 4, y);
      y += splitNonVeg.length * 3.8 + 2;
    });

    // Hydration & Key Tip
    checkPageBreak(12);
    doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
    doc.roundedRect(margin, y, contentWidth, 10, 1.5, 1.5, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(navy[0], navy[1], navy[2]);
    doc.text(`HYDRATION: ${diet.hydrationGoal}`, margin + 3, y + 4);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(muted[0], muted[1], muted[2]);
    doc.text(`TIP: ${diet.keyNutritionTip}`, margin + 3, y + 8);
    y += 14;
  });

  // Save the PDF
  doc.save(program.pdfFileName);
};
