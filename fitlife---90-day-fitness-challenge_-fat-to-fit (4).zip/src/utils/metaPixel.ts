/**
 * Meta Pixel helper for FitLife 90-Day Challenge
 * Pixel ID: 1095750506166785
 * Built directly on official Meta Pixel JavaScript SDK with full Advanced Matching
 * for real customer data (email, phone, name, order ID).
 */

declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
    _fbq?: any;
  }
}

export const META_PIXEL_ID = '1095750506166785';

export interface CustomerData {
  email?: string;
  name?: string;
  phone?: string;
  city?: string;
  state?: string;
  zip?: string;
  country?: string;
  external_id?: string;
}

/**
 * Check if a test event code is provided in URL (?test_event_code=...) or localStorage.
 * If none is provided, it operates in normal live production mode to track REAL customer data.
 */
export const getTestEventCode = (): string | undefined => {
  if (typeof window === 'undefined') return undefined;
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const fromUrl = urlParams.get('test_event_code');
    if (fromUrl) return fromUrl;
    const fromStorage = localStorage.getItem('meta_pixel_test_code');
    if (fromStorage) return fromStorage;
    return undefined;
  } catch {
    return undefined;
  }
};

/**
 * Format customer data for Meta Pixel Advanced Matching
 */
export const formatAdvancedMatching = (customer?: CustomerData): Record<string, string> => {
  if (!customer) return {};
  const names = (customer.name || '').trim().split(' ');
  const firstName = names[0] || '';
  const lastName = names.slice(1).join(' ') || '';

  const matching: Record<string, string> = {};
  if (customer.email && customer.email.trim()) {
    matching.em = customer.email.trim().toLowerCase();
  }
  if (firstName) {
    matching.fn = firstName.trim().toLowerCase();
  }
  if (lastName) {
    matching.ln = lastName.trim().toLowerCase();
  }
  if (customer.phone && customer.phone.trim()) {
    matching.ph = customer.phone.replace(/\D/g, '');
  }
  if (customer.city && customer.city.trim()) {
    matching.ct = customer.city.trim().toLowerCase();
  }
  matching.country = (customer.country || 'in').toLowerCase();
  if (customer.external_id) {
    matching.external_id = customer.external_id;
  }

  return matching;
};

/**
 * Update real customer data (Advanced Matching)
 */
export const setPixelCustomerData = (customer: CustomerData) => {
  if (typeof window === 'undefined') return;
  try {
    const matching = formatAdvancedMatching(customer);
    if (Object.keys(matching).length > 0 && typeof window.fbq === 'function') {
      window.fbq('init', META_PIXEL_ID, matching);
      console.log('[Meta Pixel] Advanced Matching updated with real customer data:', {
        hasEmail: !!matching.em,
        hasPhone: !!matching.ph,
        hasName: !!matching.fn
      });
    }
  } catch (err) {
    console.warn('[Meta Pixel] Failed to update customer data:', err);
  }
};

/**
 * Safe invocation of Meta Pixel events
 */
export const trackFbq = (
  eventType: 'track' | 'trackCustom',
  eventName: string,
  params?: Record<string, any>
) => {
  try {
    const testCode = getTestEventCode();
    const eventData = {
      ...(params || {}),
      ...(testCode ? { test_event_code: testCode } : {})
    };
    const options = testCode ? { test_event_code: testCode } : undefined;

    if (typeof window !== 'undefined' && typeof window.fbq === 'function') {
      if (options) {
        window.fbq(eventType, eventName, eventData, options);
      } else {
        window.fbq(eventType, eventName, eventData);
      }
      console.log(`[Meta Pixel] ${eventType} -> ${eventName}`, eventData);
    } else {
      console.debug(`[Meta Pixel Mock/Blocked] ${eventType} -> ${eventName}`, eventData);
    }
  } catch (err) {
    console.warn('[Meta Pixel] Failed to track event:', err);
  }
};

/**
 * Track SPA PageView whenever routes change
 */
export const trackPageView = (pageName?: string) => {
  try {
    trackFbq('track', 'PageView', pageName ? { page_name: pageName } : undefined);
  } catch (err) {
    console.warn('[Meta Pixel] PageView error:', err);
  }
};

/**
 * Track when a user views a specific program / 90-day challenge / package
 */
export const trackViewContent = (params: {
  content_name: string;
  content_category?: string;
  content_ids?: string[];
  value?: number;
  currency?: string;
}) => {
  trackFbq('track', 'ViewContent', {
    content_name: params.content_name,
    content_category: params.content_category || 'Fitness & Diet Plans',
    content_ids: params.content_ids || [],
    content_type: 'product',
    value: params.value ?? 0,
    currency: params.currency || 'INR',
  });
};

/**
 * Track when an item is added to the cart
 */
export const trackAddToCart = (params: {
  content_name: string;
  content_ids: string[];
  value: number;
  currency?: string;
}) => {
  trackFbq('track', 'AddToCart', {
    content_name: params.content_name,
    content_ids: params.content_ids,
    content_type: 'product',
    value: params.value,
    currency: params.currency || 'INR',
  });
};

/**
 * Track when checkout is initiated or Buy Now is clicked
 */
export const trackInitiateCheckout = (params: {
  value: number;
  num_items: number;
  content_ids?: string[];
  currency?: string;
  customer?: CustomerData;
}) => {
  if (params.customer) {
    setPixelCustomerData(params.customer);
  }
  trackFbq('track', 'InitiateCheckout', {
    value: params.value,
    currency: params.currency || 'INR',
    num_items: params.num_items,
    content_ids: params.content_ids || [],
    content_type: 'product',
  });
};

/**
 * Track when payment information is selected (e.g. UPI, QR, Card)
 */
export const trackAddPaymentInfo = (params: {
  payment_type: string;
  value?: number;
  currency?: string;
  customer?: CustomerData;
}) => {
  if (params.customer) {
    setPixelCustomerData(params.customer);
  }
  trackFbq('track', 'AddPaymentInfo', {
    payment_type: params.payment_type,
    value: params.value,
    currency: params.currency || 'INR',
  });
};

/**
 * Track verified purchase conversion with real customer data
 */
export const trackPurchase = (params: {
  value: number;
  currency?: string;
  content_ids: string[];
  content_name?: string;
  order_id?: string;
  num_items?: number;
  customer?: CustomerData;
}) => {
  if (params.customer) {
    setPixelCustomerData(params.customer);
  }
  trackFbq('track', 'Purchase', {
    value: params.value,
    currency: params.currency || 'INR',
    content_ids: params.content_ids,
    content_name: params.content_name || 'Fitness Program Purchase',
    content_type: 'product',
    num_items: params.num_items || params.content_ids.length,
    order_id: params.order_id,
  });
};

/**
 * Track leads (e.g. Free Preview download, BMI Calculation, Newsletter)
 */
export const trackLead = (params?: {
  content_name?: string;
  value?: number;
  currency?: string;
  customer?: CustomerData;
}) => {
  if (params?.customer) {
    setPixelCustomerData(params.customer);
  }
  trackFbq('track', 'Lead', {
    content_name: params?.content_name || 'Fitness Lead',
    value: params?.value ?? 0,
    currency: params?.currency || 'INR',
  });
};

/**
 * Track contact form inquiries
 */
export const trackContact = (params?: {
  method?: string;
  subject?: string;
  customer?: CustomerData;
}) => {
  if (params?.customer) {
    setPixelCustomerData(params.customer);
  }
  trackFbq('track', 'Contact', params);
};

/**
 * Track custom events
 */
export const trackCustomEvent = (eventName: string, params?: Record<string, any>) => {
  trackFbq('trackCustom', eventName, params);
};
