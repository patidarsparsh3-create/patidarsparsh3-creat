import { createClient } from '@supabase/supabase-js';
import { Order, CartItem } from '../types';

export const SUPABASE_PROJECT_ID = 'rannibdnszwyzdlpbfgx';
export const SUPABASE_URL = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) || `https://${SUPABASE_PROJECT_ID}.supabase.co`;
export const SUPABASE_ANON_KEY = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) || 'sb_publishable_yfCbIRbYtj10wnfxhnDABA_bIX8jYCd';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true
  }
});

export interface SupabaseOrderRecord {
  id?: string;
  order_id: string;
  customer_name: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  total: number;
  payment_method: string;
  payment_status: string;
  transaction_id: string;
  fitness_goal?: string;
  created_at?: string;
}

/**
 * Persist an order to Supabase database.
 * Attempts to insert into 'orders' or 'purchases' table.
 */
export async function saveOrderToSupabase(order: Order, fitnessGoal?: string): Promise<{ success: boolean; error?: string }> {
  try {
    const payload = {
      order_id: order.orderId,
      customer_name: order.customerName,
      items: order.items,
      subtotal: order.subtotal,
      discount: order.discount,
      total: order.total,
      payment_method: order.paymentMethod,
      payment_status: order.paymentStatus,
      transaction_id: order.transactionId,
      fitness_goal: fitnessGoal || 'General Fitness',
      created_at: new Date().toISOString()
    };

    // Try inserting into 'orders' table
    const { error } = await supabase.from('orders').insert([payload]);

    if (error) {
      console.warn('Supabase insert into "orders" returned notice:', error.message);
      
      // Fallback: try inserting into 'purchases' table if 'orders' doesn't exist
      const fallback = await supabase.from('purchases').insert([payload]);
      if (fallback.error) {
        console.warn('Supabase insert into "purchases" fallback notice:', fallback.error.message);
        return { success: false, error: error.message };
      }
    }

    return { success: true };
  } catch (err: any) {
    console.error('Supabase saveOrder exception:', err);
    return { success: false, error: err?.message || 'Network error' };
  }
}

/**
 * Fetch customer orders from Supabase by customer name or order ID
 */
export async function fetchCustomerOrdersFromSupabase(customerName?: string): Promise<Order[]> {
  try {
    let query = supabase.from('orders').select('*').order('created_at', { ascending: false });
    
    if (customerName && customerName.trim() !== '') {
      query = query.ilike('customer_name', customerName.trim());
    }

    const { data, error } = await query;
    if (error || !data) {
      return [];
    }

    return data.map((d: any) => ({
      orderId: d.order_id || d.id,
      date: new Date(d.created_at || Date.now()).toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      }),
      customerName: d.customer_name,
      items: Array.isArray(d.items) ? d.items : [],
      subtotal: Number(d.subtotal || d.total || 250),
      discount: Number(d.discount || 0),
      total: Number(d.total || 250),
      paymentMethod: d.payment_method || 'UPI',
      paymentStatus: d.payment_status || 'completed',
      transactionId: d.transaction_id || `TXN_${d.order_id}`
    }));
  } catch {
    return [];
  }
}

/**
 * Check connectivity to Supabase
 */
export async function testSupabaseConnection(): Promise<{ connected: boolean; message: string }> {
  try {
    // Ping Supabase with a lightweight query
    const { error } = await supabase.from('orders').select('count', { count: 'exact', head: true });
    if (error && error.code !== 'PGRST116') {
      // If table doesn't exist yet or permission error, the server still responded
      return {
        connected: true,
        message: `Connected to Supabase project "${SUPABASE_PROJECT_ID}". (Table status: ${error.message})`
      };
    }
    return {
      connected: true,
      message: `Connected successfully to Supabase project "${SUPABASE_PROJECT_ID}".`
    };
  } catch (err: any) {
    return {
      connected: false,
      message: err?.message || 'Could not connect to Supabase.'
    };
  }
}
