/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { HomePage } from './components/pages/HomePage';
import { NinetyDayChallengePage } from './components/pages/NinetyDayChallengePage';
import { ProgramDetailPage } from './components/pages/ProgramDetailPage';
import { ShopPage } from './components/pages/ShopPage';
import { CartPage } from './components/pages/CartPage';
import { CheckoutPage } from './components/pages/CheckoutPage';
import { OrderConfirmationPage } from './components/pages/OrderConfirmationPage';
import { MyAccountPage } from './components/pages/MyAccountPage';
import { DownloadPlansPage } from './components/pages/DownloadPlansPage';
import { AboutPage } from './components/pages/AboutPage';
import { FAQPage } from './components/pages/FAQPage';
import { ContactPage } from './components/pages/ContactPage';
import { FreePreviewModal } from './components/common/FreePreviewModal';
import { BMICalculatorModal } from './components/common/BMICalculatorModal';
import { PaymentScannerModal } from './components/common/PaymentScannerModal';
import { ThankYouModal } from './components/common/ThankYouModal';
import { AuthModal } from './components/pages/AuthModal';
import { PROGRAMS } from './data/programsData';
import { CheckCircle2 } from 'lucide-react';

const AppContent: React.FC = () => {
  const {
    currentPage,
    toastMessage,
    scannerProgram,
    setScannerProgram,
    thankYouProgram,
    setThankYouProgram,
    completeScannerPayment,
    currentOrder
  } = useApp();

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case '90-day-challenge':
        return <NinetyDayChallengePage />;
      case 'fat-loss':
        return <ProgramDetailPage program={PROGRAMS.find((p) => p.slug === 'fat-loss') || PROGRAMS[1]} />;
      case 'muscle-gain':
        return <ProgramDetailPage program={PROGRAMS.find((p) => p.slug === 'muscle-gain') || PROGRAMS[2]} />;
      case 'posture-correction':
        return <ProgramDetailPage program={PROGRAMS.find((p) => p.slug === 'posture-correction') || PROGRAMS[3]} />;
      case 'mobility-tightness':
        return <ProgramDetailPage program={PROGRAMS.find((p) => p.slug === 'mobility-tightness') || PROGRAMS[4]} />;
      case 'bone-joint':
        return <ProgramDetailPage program={PROGRAMS.find((p) => p.slug === 'bone-joint') || PROGRAMS[5] || PROGRAMS[0]} />;
      case 'shop':
        return <ShopPage />;
      case 'cart':
        return <CartPage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'order-confirmation':
        return <OrderConfirmationPage />;
      case 'my-account':
      case 'login':
        return <MyAccountPage />;
      case 'download-plans':
        return <DownloadPlansPage />;
      case 'about':
        return <AboutPage />;
      case 'faq':
        return <FAQPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-emerald-500 selection:text-white">
      {/* Top Header */}
      <Header />

      {/* Main Page Body */}
      <main className="flex-1">
        {renderCurrentPage()}
      </main>

      {/* Footer */}
      <Footer />

      {/* Global Modals */}
      <FreePreviewModal />
      <BMICalculatorModal />
      <AuthModal />
      
      {/* Payment Scanner Modal (PhonePe / UPI) */}
      <PaymentScannerModal
        program={scannerProgram}
        onClose={() => setScannerProgram(null)}
        onPaymentSuccess={(prog, utr) => completeScannerPayment(prog, utr)}
      />

      {/* Thank You Celebration & Automated Download Modal */}
      <ThankYouModal
        program={thankYouProgram}
        orderId={currentOrder?.orderId}
        onClose={() => setThankYouProgram(null)}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 border border-slate-700 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
