export type Page =
  | 'home'
  | '90-day-challenge'
  | 'fat-loss'
  | 'muscle-gain'
  | 'posture-correction'
  | 'mobility-tightness'
  | 'bone-joint'
  | 'shop'
  | 'about'
  | 'faq'
  | 'contact'
  | 'login'
  | 'cart'
  | 'checkout'
  | 'my-account'
  | 'download-plans'
  | 'order-confirmation';

export interface Exercise {
  name: string;
  targetMuscle: string;
  sets: string;
  repsOrTime: string;
  rest: string;
  formCue: string;
}

export interface DayWorkout {
  dayNumber: number;
  dayTitle: string;
  focus: string;
  warmUp: string;
  exercises: Exercise[];
  coolDown: string;
  cardioStepGoal: string;
  isRestDay?: boolean;
}

export interface DayMealPlan {
  dayNumber: number;
  calorieTarget: string;
  breakfast: {
    veg: string;
    nonVeg: string;
    calories: string;
  };
  lunch: {
    veg: string;
    nonVeg: string;
    calories: string;
  };
  snacks: {
    veg: string;
    nonVeg: string;
    calories: string;
  };
  dinner: {
    veg: string;
    nonVeg: string;
    calories: string;
  };
  hydrationGoal: string;
  keyNutritionTip: string;
}

export interface Program {
  id: string;
  slug: string;
  title: string;
  tagline: string;
  shortDesc: string;
  duration: string;
  level: string;
  price: number; // ₹250
  originalPrice: number; // e.g. ₹999
  category: 'fat-loss' | 'muscle-gain' | 'posture' | 'mobility' | 'general-wellness';
  highlights: string[];
  benefits: string[];
  targetAudience: string[];
  sampleDaysWorkout: DayWorkout[];
  sampleDaysDiet: DayMealPlan[];
  pdfFileName: string;
  badge?: string;
  accentColor: string;
}

export interface CartItem {
  programId: string;
  title: string;
  price: number;
  quantity: number;
  slug: string;
}

export interface Order {
  orderId: string;
  date: string;
  customerName: string;
  customerEmail?: string;
  customerPhone?: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: string;
  paymentStatus: 'completed' | 'pending' | 'failed';
  transactionId: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  fitnessGoal: string;
  purchasedProgramIds: string[];
  orders: Order[];
}
